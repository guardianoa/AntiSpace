using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web.Script.Serialization;
using SignBridge.Core.Models;
using SignBridge.Core.Processing;

namespace SignBridge.Core.Recognition
{
    public sealed class PrototypeRecognizer
    {
        private readonly KeypointProcessor processor;
        private readonly PrototypeModel model;

        public PrototypeModel Model { get { return model; } }

        public PrototypeRecognizer(PrototypeModel model)
        {
            if (model == null) throw new ArgumentNullException("model");
            if (model.Classes == null || model.Classes.Count == 0)
                throw new ArgumentException("The model has no sign classes.", "model");
            this.model = model;
            processor = new KeypointProcessor();
        }

        public RecognitionResult Predict(IList<LandmarkFrame> frames)
        {
            List<LandmarkFrame> prepared = processor.Prepare(frames, model.FrameCount);
            return PredictFeatures(processor.BuildFeatureMatrix(prepared));
        }

        public RecognitionResult PredictFeatures(double[][] query)
        {
            List<PredictionAlternative> alternatives = new List<PredictionAlternative>();
            foreach (ClassPrototype signClass in model.Classes)
            {
                double best = double.PositiveInfinity;
                foreach (double[][] example in signClass.Examples)
                    best = Math.Min(best, DtwDistance(query, example));
                alternatives.Add(new PredictionAlternative { Label = signClass.Label, Distance = best });
            }
            alternatives = alternatives.OrderBy(delegate(PredictionAlternative a) { return a.Distance; }).ToList();

            double bestDistance = alternatives[0].Distance;
            double temperature = Math.Max(0.025, bestDistance + 0.05);
            double probabilitySum = 0.0;
            for (int i = 0; i < alternatives.Count; i++)
            {
                alternatives[i].Probability = Math.Exp(-(alternatives[i].Distance - bestDistance) / temperature);
                probabilitySum += alternatives[i].Probability;
            }
            for (int i = 0; i < alternatives.Count; i++) alternatives[i].Probability /= probabilitySum;

            ClassPrototype winner = model.Classes.First(delegate(ClassPrototype c) { return c.Label == alternatives[0].Label; });
            bool tooFar = bestDistance > winner.RejectionDistance;
            bool ambiguous = alternatives.Count > 1 && alternatives[1].Distance <= bestDistance * 1.08 + 0.002;

            RecognitionResult result = new RecognitionResult();
            result.Distance = bestDistance;
            result.Confidence = alternatives[0].Probability;
            result.Rejected = tooFar || ambiguous;
            result.Label = result.Rejected ? "알 수 없음" : alternatives[0].Label;
            result.Reason = tooFar ? "학습 범위 밖의 동작" : (ambiguous ? "후보 간 차이가 작음" : string.Empty);
            result.Alternatives = alternatives.Take(3).ToList();
            return result;
        }

        public static PrototypeModel Train(IList<SignSequence> sequences, int frameCount, int maxExamplesPerClass, out TrainingReport report)
        {
            if (sequences == null || sequences.Count == 0)
                throw new ArgumentException("Training requires at least one sequence.", "sequences");
            if (maxExamplesPerClass < 1) throw new ArgumentOutOfRangeException("maxExamplesPerClass");

            report = new TrainingReport();
            report.SequenceCount = sequences.Count;
            KeypointProcessor processor = new KeypointProcessor();
            PrototypeModel model = new PrototypeModel();
            model.FrameCount = frameCount;
            model.FeatureDimension = KeypointProcessor.FeatureDimension;

            IEnumerable<IGrouping<string, SignSequence>> groups = sequences
                .Where(delegate(SignSequence s) { return s != null && s.Frames != null && s.Frames.Count > 0 && !string.IsNullOrWhiteSpace(s.Label); })
                .GroupBy(delegate(SignSequence s) { return s.Label; }, StringComparer.OrdinalIgnoreCase)
                .OrderBy(delegate(IGrouping<string, SignSequence> g) { return g.Key; });

            foreach (IGrouping<string, SignSequence> group in groups)
            {
                ClassPrototype signClass = new ClassPrototype();
                signClass.Label = group.Key;
                List<double[][]> all = new List<double[][]>();
                foreach (SignSequence sequence in group)
                {
                    List<LandmarkFrame> prepared = processor.Prepare(sequence.Frames, frameCount);
                    all.Add(processor.BuildFeatureMatrix(prepared));
                }
                signClass.SampleCount = all.Count;
                signClass.Examples.AddRange(SelectEvenly(all, maxExamplesPerClass));
                signClass.RejectionDistance = EstimateRejectionDistance(signClass.Examples);
                if (all.Count < 3)
                    report.Warnings.Add(group.Key + ": fewer than 3 samples; rejection calibration is unreliable.");
                report.SamplesPerClass[group.Key] = all.Count;
                model.Classes.Add(signClass);
            }

            model.Classes = model.Classes.Where(delegate(ClassPrototype c) { return c.Examples.Count > 0; }).ToList();
            report.ClassCount = model.Classes.Count;
            if (model.Classes.Count < 2)
                report.Warnings.Add("At least two sign classes are required for meaningful recognition.");
            return model;
        }

        public static EvaluationReport EvaluateLeaveOneOut(IList<SignSequence> sequences, int frameCount)
        {
            KeypointProcessor processor = new KeypointProcessor();
            List<double[][]> features = new List<double[][]>();
            for (int i = 0; i < sequences.Count; i++)
                features.Add(processor.BuildFeatureMatrix(processor.Prepare(sequences[i].Frames, frameCount)));

            EvaluationReport report = new EvaluationReport();
            for (int i = 0; i < sequences.Count; i++)
            {
                double best = double.PositiveInfinity;
                string predicted = "알 수 없음";
                for (int j = 0; j < sequences.Count; j++)
                {
                    if (i == j) continue;
                    double distance = DtwDistance(features[i], features[j]);
                    if (distance < best) { best = distance; predicted = sequences[j].Label; }
                }
                string actual = sequences[i].Label;
                if (!report.Confusion.ContainsKey(actual)) report.Confusion[actual] = new Dictionary<string, int>();
                if (!report.Confusion[actual].ContainsKey(predicted)) report.Confusion[actual][predicted] = 0;
                report.Confusion[actual][predicted]++;
                report.Total++;
                if (string.Equals(actual, predicted, StringComparison.OrdinalIgnoreCase)) report.Correct++;
            }
            return report;
        }

        public static void Save(PrototypeModel model, string path)
        {
            JavaScriptSerializer serializer = NewSerializer();
            string directory = Path.GetDirectoryName(Path.GetFullPath(path));
            if (!Directory.Exists(directory)) Directory.CreateDirectory(directory);
            string temporaryPath = path + ".tmp";
            string backupPath = path + ".bak";
            File.WriteAllText(temporaryPath, serializer.Serialize(model));
            if (File.Exists(path))
            {
                if (File.Exists(backupPath)) File.Delete(backupPath);
                File.Replace(temporaryPath, path, backupPath);
            }
            else
            {
                File.Move(temporaryPath, path);
            }
        }

        public static PrototypeModel Load(string path)
        {
            JavaScriptSerializer serializer = NewSerializer();
            PrototypeModel model = serializer.Deserialize<PrototypeModel>(File.ReadAllText(path));
            if (model == null || model.SchemaVersion != "signbridge-prototype-v1")
                throw new InvalidDataException("Unsupported or damaged SignBridge model.");
            return model;
        }

        public static double DtwDistance(double[][] left, double[][] right)
        {
            int n = left.Length, m = right.Length;
            int band = Math.Max(8, Math.Abs(n - m) + 2);
            double[,] cost = new double[n + 1, m + 1];
            for (int i = 0; i <= n; i++) for (int j = 0; j <= m; j++) cost[i, j] = double.PositiveInfinity;
            cost[0, 0] = 0.0;

            for (int i = 1; i <= n; i++)
            {
                int from = Math.Max(1, i - band);
                int to = Math.Min(m, i + band);
                for (int j = from; j <= to; j++)
                {
                    double previous = Math.Min(cost[i - 1, j], Math.Min(cost[i, j - 1], cost[i - 1, j - 1]));
                    cost[i, j] = FrameDistance(left[i - 1], right[j - 1]) + previous;
                }
            }
            return cost[n, m] / (n + m);
        }

        private static double FrameDistance(double[] left, double[] right)
        {
            double sum = 0.0, weightSum = 0.0;
            int confidenceOffset = LandmarkFrame.BodyHandCount * 3;
            for (int joint = 0; joint < LandmarkFrame.BodyHandCount; joint++)
            {
                double confidence = Math.Min(left[confidenceOffset + joint], right[confidenceOffset + joint]);
                if (confidence < 0.01) continue;
                double weight = 0.25 + confidence * 0.75;
                int offset = joint * 3;
                for (int axis = 0; axis < 3; axis++)
                {
                    double difference = left[offset + axis] - right[offset + axis];
                    sum += difference * difference * weight;
                    weightSum += weight;
                }
            }
            int faceOffset = LandmarkFrame.BodyHandCount * 4;
            for (int i = 0; i < KeypointProcessor.FaceFeatureCount; i++)
            {
                double difference = left[faceOffset + i] - right[faceOffset + i];
                sum += difference * difference * 2.5;
                weightSum += 2.5;
            }
            return weightSum < 1e-8 ? 1000.0 : sum / weightSum;
        }

        private static List<double[][]> SelectEvenly(List<double[][]> all, int maximum)
        {
            if (all.Count <= maximum) return all;
            if (maximum == 1) return new List<double[][]> { all[0] };
            List<double[][]> output = new List<double[][]>();
            for (int i = 0; i < maximum; i++)
            {
                int index = (int)Math.Round(i * (all.Count - 1.0) / (maximum - 1.0));
                output.Add(all[index]);
            }
            return output;
        }

        private static double EstimateRejectionDistance(List<double[][]> samples)
        {
            if (samples.Count < 2) return 1000000.0;
            List<double> nearest = new List<double>();
            for (int i = 0; i < samples.Count; i++)
            {
                double best = double.PositiveInfinity;
                for (int j = 0; j < samples.Count; j++) if (i != j) best = Math.Min(best, DtwDistance(samples[i], samples[j]));
                nearest.Add(best);
            }
            double mean = nearest.Average();
            double variance = nearest.Select(delegate(double d) { double x = d - mean; return x * x; }).Average();
            return Math.Max(mean + 2.5 * Math.Sqrt(variance), mean * 1.2 + 0.002);
        }

        private static JavaScriptSerializer NewSerializer()
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            serializer.MaxJsonLength = int.MaxValue;
            serializer.RecursionLimit = 1024;
            return serializer;
        }
    }
}
