using System;
using System.Collections.Generic;

namespace SignBridge.Core.Recognition
{
    [Serializable]
    public sealed class PrototypeModel
    {
        public string SchemaVersion { get; set; }
        public string CreatedUtc { get; set; }
        public int FrameCount { get; set; }
        public int FeatureDimension { get; set; }
        public List<ClassPrototype> Classes { get; set; }

        public PrototypeModel()
        {
            SchemaVersion = "signbridge-prototype-v1";
            CreatedUtc = DateTime.UtcNow.ToString("o");
            Classes = new List<ClassPrototype>();
        }
    }

    [Serializable]
    public sealed class ClassPrototype
    {
        public string Label { get; set; }
        public int SampleCount { get; set; }
        public double RejectionDistance { get; set; }
        public List<double[][]> Examples { get; set; }

        public ClassPrototype()
        {
            Label = string.Empty;
            Examples = new List<double[][]>();
        }
    }

    public sealed class RecognitionResult
    {
        public string Label { get; set; }
        public double Confidence { get; set; }
        public double Distance { get; set; }
        public bool Rejected { get; set; }
        public string Reason { get; set; }
        public List<PredictionAlternative> Alternatives { get; set; }

        public RecognitionResult()
        {
            Label = "알 수 없음";
            Reason = string.Empty;
            Alternatives = new List<PredictionAlternative>();
        }
    }

    public sealed class PredictionAlternative
    {
        public string Label { get; set; }
        public double Distance { get; set; }
        public double Probability { get; set; }
    }

    public sealed class TrainingReport
    {
        public int SequenceCount { get; set; }
        public int ClassCount { get; set; }
        public Dictionary<string, int> SamplesPerClass { get; set; }
        public List<string> Warnings { get; set; }

        public TrainingReport()
        {
            SamplesPerClass = new Dictionary<string, int>();
            Warnings = new List<string>();
        }
    }

    public sealed class EvaluationReport
    {
        public int Total { get; set; }
        public int Correct { get; set; }
        public Dictionary<string, Dictionary<string, int>> Confusion { get; set; }

        public double Accuracy
        {
            get { return Total == 0 ? 0.0 : (double)Correct / Total; }
        }

        public EvaluationReport()
        {
            Confusion = new Dictionary<string, Dictionary<string, int>>();
        }
    }
}
