using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using SignBridge.Core.Data;
using SignBridge.Core.Models;

namespace SignBridge.Core.Translation
{
    public sealed class GlossTranslator
    {
        private readonly Dictionary<string, string[]> rules;

        public GlossTranslator()
        {
            rules = new Dictionary<string, string[]>(StringComparer.OrdinalIgnoreCase);
        }

        public void LoadRules(string path)
        {
            if (!File.Exists(path)) return;
            string[] lines = File.ReadAllLines(path, Encoding.UTF8);
            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i].Trim();
                if (line.Length == 0 || line.StartsWith("#")) continue;
                string[] columns = line.Split(new[] { ',' }, 2);
                if (columns.Length != 2) continue;
                string key = Normalize(columns[0]);
                string[] gloss = columns[1].Split('|').Select(delegate(string s) { return s.Trim(); })
                    .Where(delegate(string s) { return s.Length > 0; }).ToArray();
                if (key.Length > 0 && gloss.Length > 0) rules[key] = gloss;
            }
        }

        public string[] Translate(string koreanText, IEnumerable<string> availableGlosses)
        {
            string normalized = Normalize(koreanText);
            HashSet<string> available = new HashSet<string>(availableGlosses ?? new string[0], StringComparer.OrdinalIgnoreCase);
            string[] exact;
            if (rules.TryGetValue(normalized, out exact))
                return exact.Where(delegate(string g) { return available.Count == 0 || available.Contains(g); }).ToArray();

            List<Match> matches = new List<Match>();
            foreach (string gloss in available)
            {
                int index = normalized.IndexOf(Normalize(gloss), StringComparison.OrdinalIgnoreCase);
                if (index >= 0) matches.Add(new Match { Index = index, Gloss = gloss });
            }
            return matches.OrderBy(delegate(Match m) { return m.Index; })
                .ThenByDescending(delegate(Match m) { return m.Gloss.Length; })
                .Select(delegate(Match m) { return m.Gloss; }).Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
        }

        private static string Normalize(string value)
        {
            if (value == null) return string.Empty;
            char[] remove = { '?', '.', '!', ',', '。', '？', '！' };
            string normalized = value.Trim();
            for (int i = 0; i < remove.Length; i++) normalized = normalized.Replace(remove[i].ToString(), string.Empty);
            while (normalized.Contains("  ")) normalized = normalized.Replace("  ", " ");
            return normalized;
        }

        private sealed class Match
        {
            public int Index { get; set; }
            public string Gloss { get; set; }
        }
    }

    public sealed class MotionLibrary
    {
        private readonly string root;
        private readonly DatasetLoader loader;

        public MotionLibrary(string root)
        {
            this.root = root;
            loader = new DatasetLoader();
        }

        public string[] AvailableGlosses
        {
            get
            {
                if (!Directory.Exists(root)) return new string[0];
                return Directory.GetDirectories(root).Select(Path.GetFileName).OrderBy(delegate(string s) { return s; }).ToArray();
            }
        }

        public SignSequence Load(string gloss)
        {
            string labelPath = Path.Combine(root, gloss);
            if (!Directory.Exists(labelPath)) return null;
            string[] clips = Directory.GetDirectories(labelPath);
            string clipPath = clips.Length > 0 ? clips[0] : labelPath;
            return loader.LoadClipDirectory(clipPath, gloss);
        }

        public List<LandmarkFrame> Compose(IEnumerable<string> glosses, int transitionFrames)
        {
            List<LandmarkFrame> output = new List<LandmarkFrame>();
            foreach (string gloss in glosses)
            {
                SignSequence motion = Load(gloss);
                if (motion == null || motion.Frames.Count == 0) continue;
                if (output.Count > 0)
                {
                    LandmarkFrame from = output[output.Count - 1];
                    LandmarkFrame to = motion.Frames[0];
                    for (int i = 1; i <= transitionFrames; i++)
                        output.Add(LandmarkFrame.Interpolate(from, to, (double)i / (transitionFrames + 1)));
                }
                output.AddRange(motion.Frames.Select(delegate(LandmarkFrame f) { return f.Clone(); }));
            }
            return output;
        }
    }
}
