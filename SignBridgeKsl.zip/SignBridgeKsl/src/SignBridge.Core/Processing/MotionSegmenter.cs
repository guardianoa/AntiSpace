using System;
using System.Collections.Generic;
using SignBridge.Core.Models;

namespace SignBridge.Core.Processing
{
    public sealed class MotionSegmenter
    {
        private readonly Queue<LandmarkFrame> preRoll;
        private readonly List<LandmarkFrame> recording;
        private readonly KeypointProcessor processor;
        private LandmarkFrame previous;
        private int movingFrames;
        private int quietFrames;

        public int PreRollFrames { get; set; }
        public int StartFrames { get; set; }
        public int StopFrames { get; set; }
        public int MinimumFrames { get; set; }
        public int MaximumFrames { get; set; }
        public double StartThreshold { get; set; }
        public double StopThreshold { get; set; }
        public bool IsRecording { get; private set; }

        public MotionSegmenter()
        {
            preRoll = new Queue<LandmarkFrame>();
            recording = new List<LandmarkFrame>();
            processor = new KeypointProcessor();
            PreRollFrames = 8;
            StartFrames = 3;
            StopFrames = 9;
            MinimumFrames = 15;
            MaximumFrames = 120;
            StartThreshold = 0.018;
            StopThreshold = 0.007;
        }

        public List<LandmarkFrame> AddFrame(LandmarkFrame rawFrame)
        {
            if (rawFrame == null) return null;
            LandmarkFrame normalized = processor.Normalize(rawFrame);
            double energy = previous == null ? 0.0 : MotionEnergy(previous, normalized);
            previous = normalized;

            if (!IsRecording)
            {
                preRoll.Enqueue(rawFrame.Clone());
                while (preRoll.Count > PreRollFrames) preRoll.Dequeue();
                movingFrames = energy >= StartThreshold ? movingFrames + 1 : 0;
                if (movingFrames >= StartFrames)
                {
                    recording.Clear();
                    recording.AddRange(preRoll);
                    preRoll.Clear();
                    IsRecording = true;
                    quietFrames = 0;
                }
                return null;
            }

            recording.Add(rawFrame.Clone());
            quietFrames = energy <= StopThreshold ? quietFrames + 1 : 0;
            bool stopped = quietFrames >= StopFrames && recording.Count >= MinimumFrames;
            bool timedOut = recording.Count >= MaximumFrames;
            if (!stopped && !timedOut) return null;

            int keep = stopped ? Math.Max(MinimumFrames, recording.Count - Math.Max(0, quietFrames - 2)) : recording.Count;
            List<LandmarkFrame> completed = recording.GetRange(0, Math.Min(keep, recording.Count));
            ResetRecordingState(rawFrame);
            return completed;
        }

        public void Reset()
        {
            preRoll.Clear();
            recording.Clear();
            previous = null;
            movingFrames = 0;
            quietFrames = 0;
            IsRecording = false;
        }

        private void ResetRecordingState(LandmarkFrame lastFrame)
        {
            recording.Clear();
            preRoll.Clear();
            preRoll.Enqueue(lastFrame.Clone());
            movingFrames = 0;
            quietFrames = 0;
            IsRecording = false;
        }

        private static double MotionEnergy(LandmarkFrame previous, LandmarkFrame current)
        {
            double maximum = 0.0;
            int[] important = { 4, 7, 8, 12, 16, 20, 24, 28, 29, 33, 37, 41, 45, 49 };
            for (int i = 0; i < important.Length; i++)
            {
                int index = important[i];
                LandmarkPoint a = previous.BodyHands[index], b = current.BodyHands[index];
                if (!a.IsValid || !b.IsValid) continue;
                double x = a.X - b.X, y = a.Y - b.Y, z = a.Z - b.Z;
                maximum = Math.Max(maximum, Math.Sqrt(x * x + y * y + z * z));
            }
            return maximum;
        }
    }
}
