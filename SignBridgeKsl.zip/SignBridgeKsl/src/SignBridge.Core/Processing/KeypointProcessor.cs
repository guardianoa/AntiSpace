using System;
using System.Collections.Generic;
using SignBridge.Core.Models;

namespace SignBridge.Core.Processing
{
    public sealed class KeypointProcessor
    {
        public const int DefaultFrameCount = 60;
        public const int FaceFeatureCount = 10;
        public const int FeatureDimension = LandmarkFrame.BodyHandCount * 4 + FaceFeatureCount;

        public List<LandmarkFrame> Prepare(IList<LandmarkFrame> source, int frameCount)
        {
            if (source == null || source.Count == 0)
                throw new ArgumentException("At least one landmark frame is required.", "source");
            if (frameCount < 2) throw new ArgumentOutOfRangeException("frameCount");

            List<LandmarkFrame> repaired = FillMissing(source);
            List<LandmarkFrame> smoothed = Smooth(repaired, 1);
            return Resample(smoothed, frameCount);
        }

        public double[][] BuildFeatureMatrix(IList<LandmarkFrame> frames)
        {
            double[][] output = new double[frames.Count][];
            for (int i = 0; i < frames.Count; i++) output[i] = BuildFeatures(frames[i]);
            return output;
        }

        public double[] BuildFeatures(LandmarkFrame frame)
        {
            LandmarkFrame normalized = Normalize(frame);
            double[] vector = new double[FeatureDimension];
            int offset = 0;
            for (int i = 0; i < LandmarkFrame.BodyHandCount; i++)
            {
                LandmarkPoint point = normalized.BodyHands[i];
                bool valid = point != null && point.IsValid;
                vector[offset++] = valid ? point.X : 0.0;
                vector[offset++] = valid ? point.Y : 0.0;
                vector[offset++] = valid ? point.Z : 0.0;
            }
            for (int i = 0; i < LandmarkFrame.BodyHandCount; i++)
            {
                LandmarkPoint point = normalized.BodyHands[i];
                vector[offset++] = point != null && point.IsValid ? Clamp(point.Confidence, 0.0, 1.0) : 0.0;
            }

            double[] face = ExtractFaceFeatures(frame.Face);
            Array.Copy(face, 0, vector, offset, face.Length);
            return vector;
        }

        public LandmarkFrame Normalize(LandmarkFrame source)
        {
            LandmarkFrame output = source.Clone();
            LandmarkPoint rightShoulder = source.BodyHands[2];
            LandmarkPoint leftShoulder = source.BodyHands[5];

            double centerX = 0.0, centerY = 0.0, centerZ = 0.0, scale = 1.0;
            if (rightShoulder.IsValid && leftShoulder.IsValid)
            {
                centerX = (rightShoulder.X + leftShoulder.X) * 0.5;
                centerY = (rightShoulder.Y + leftShoulder.Y) * 0.5;
                centerZ = (rightShoulder.Z + leftShoulder.Z) * 0.5;
                scale = Distance3(rightShoulder, leftShoulder);
                if (scale < 1e-8) scale = 1.0;
            }

            for (int i = 0; i < output.BodyHands.Length; i++)
            {
                LandmarkPoint point = output.BodyHands[i];
                if (!point.IsValid) continue;
                point.X = (point.X - centerX) / scale;
                point.Y = (point.Y - centerY) / scale;
                point.Z = (point.Z - centerZ) / scale;
            }
            return output;
        }

        public List<LandmarkFrame> Resample(IList<LandmarkFrame> frames, int frameCount)
        {
            List<LandmarkFrame> output = new List<LandmarkFrame>(frameCount);
            if (frames.Count == 1)
            {
                for (int i = 0; i < frameCount; i++) output.Add(frames[0].Clone());
                return output;
            }

            for (int i = 0; i < frameCount; i++)
            {
                double sourcePosition = i * (frames.Count - 1.0) / (frameCount - 1.0);
                int left = (int)Math.Floor(sourcePosition);
                int right = Math.Min(left + 1, frames.Count - 1);
                output.Add(LandmarkFrame.Interpolate(frames[left], frames[right], sourcePosition - left));
            }
            return output;
        }

        private static List<LandmarkFrame> FillMissing(IList<LandmarkFrame> source)
        {
            List<LandmarkFrame> output = new List<LandmarkFrame>(source.Count);
            for (int i = 0; i < source.Count; i++) output.Add(source[i].Clone());

            for (int joint = 0; joint < LandmarkFrame.BodyHandCount; joint++)
            {
                LandmarkPoint last = null;
                for (int frame = 0; frame < output.Count; frame++)
                {
                    LandmarkPoint current = output[frame].BodyHands[joint];
                    if (current.IsValid) last = current.Clone();
                    else if (last != null) output[frame].BodyHands[joint] = last.Clone();
                }
                last = null;
                for (int frame = output.Count - 1; frame >= 0; frame--)
                {
                    LandmarkPoint current = output[frame].BodyHands[joint];
                    if (current.IsValid) last = current.Clone();
                    else if (last != null) output[frame].BodyHands[joint] = last.Clone();
                }
            }
            return output;
        }

        private static List<LandmarkFrame> Smooth(IList<LandmarkFrame> source, int radius)
        {
            List<LandmarkFrame> output = new List<LandmarkFrame>(source.Count);
            for (int frameIndex = 0; frameIndex < source.Count; frameIndex++)
            {
                LandmarkFrame frame = source[frameIndex].Clone();
                for (int joint = 0; joint < LandmarkFrame.BodyHandCount; joint++)
                    frame.BodyHands[joint] = AveragePoint(source, frameIndex, joint, radius, false);
                for (int faceIndex = 0; faceIndex < frame.Face.Length; faceIndex++)
                    frame.Face[faceIndex] = AveragePoint(source, frameIndex, faceIndex, radius, true);
                output.Add(frame);
            }
            return output;
        }

        private static LandmarkPoint AveragePoint(IList<LandmarkFrame> source, int frameIndex, int pointIndex, int radius, bool face)
        {
            double x = 0, y = 0, z = 0, confidence = 0;
            int count = 0;
            int start = Math.Max(0, frameIndex - radius);
            int end = Math.Min(source.Count - 1, frameIndex + radius);
            for (int i = start; i <= end; i++)
            {
                LandmarkPoint[] points = face ? source[i].Face : source[i].BodyHands;
                if (pointIndex >= points.Length || points[pointIndex] == null || !points[pointIndex].IsValid) continue;
                x += points[pointIndex].X; y += points[pointIndex].Y; z += points[pointIndex].Z;
                confidence += points[pointIndex].Confidence; count++;
            }
            return count == 0 ? new LandmarkPoint() : new LandmarkPoint(x / count, y / count, z / count, confidence / count);
        }

        private static double[] ExtractFaceFeatures(LandmarkPoint[] face)
        {
            double[] value = new double[FaceFeatureCount];
            if (face == null || face.Length < 68) return value;

            LandmarkPoint leftEyeCenter = Mid(face[36], face[39]);
            LandmarkPoint rightEyeCenter = Mid(face[42], face[45]);
            double eyeDistance = Distance2(leftEyeCenter, rightEyeCenter);
            if (eyeDistance < 1e-8) return value;

            value[0] = Average(Distance2(face[37], face[41]), Distance2(face[38], face[40])) / eyeDistance;
            value[1] = Average(Distance2(face[43], face[47]), Distance2(face[44], face[46])) / eyeDistance;
            double mouthWidth = Distance2(face[48], face[54]);
            value[2] = Average(Distance2(face[61], face[67]), Distance2(face[62], face[66]), Distance2(face[63], face[65])) / Math.Max(mouthWidth, 1e-8);
            value[3] = mouthWidth / eyeDistance;
            value[4] = Average(Distance2(face[19], face[37]), Distance2(face[20], face[38])) / eyeDistance;
            value[5] = Average(Distance2(face[23], face[43]), Distance2(face[24], face[44])) / eyeDistance;
            value[6] = Math.Atan2(rightEyeCenter.Y - leftEyeCenter.Y, rightEyeCenter.X - leftEyeCenter.X) / Math.PI;
            LandmarkPoint eyeMid = Mid(leftEyeCenter, rightEyeCenter);
            value[7] = (face[30].X - eyeMid.X) / eyeDistance;
            value[8] = (face[54].Y - face[48].Y) / Math.Max(mouthWidth, 1e-8);
            value[9] = value[4] - value[5];
            for (int i = 0; i < value.Length; i++) value[i] = Clamp(value[i], -4.0, 4.0);
            return value;
        }

        private static LandmarkPoint Mid(LandmarkPoint a, LandmarkPoint b)
        {
            if (a == null || b == null || !a.IsValid || !b.IsValid) return new LandmarkPoint();
            return new LandmarkPoint((a.X + b.X) * 0.5, (a.Y + b.Y) * 0.5, (a.Z + b.Z) * 0.5, Math.Min(a.Confidence, b.Confidence));
        }

        private static double Distance2(LandmarkPoint a, LandmarkPoint b)
        {
            if (a == null || b == null || !a.IsValid || !b.IsValid) return 0.0;
            double x = a.X - b.X, y = a.Y - b.Y;
            return Math.Sqrt(x * x + y * y);
        }

        private static double Distance3(LandmarkPoint a, LandmarkPoint b)
        {
            double x = a.X - b.X, y = a.Y - b.Y, z = a.Z - b.Z;
            return Math.Sqrt(x * x + y * y + z * z);
        }

        private static double Average(params double[] values)
        {
            double sum = 0.0;
            for (int i = 0; i < values.Length; i++) sum += values[i];
            return values.Length == 0 ? 0.0 : sum / values.Length;
        }

        private static double Clamp(double value, double minimum, double maximum)
        {
            return Math.Max(minimum, Math.Min(maximum, value));
        }
    }
}
