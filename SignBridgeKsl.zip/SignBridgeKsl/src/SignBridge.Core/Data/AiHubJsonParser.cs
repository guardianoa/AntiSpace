using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Web.Script.Serialization;
using SignBridge.Core.Models;

namespace SignBridge.Core.Data
{
    public sealed class AiHubJsonParser
    {
        private static readonly int[] PoseIndices = { 0, 1, 2, 3, 4, 5, 6, 7 };
        private readonly JavaScriptSerializer serializer;

        public AiHubJsonParser()
        {
            serializer = new JavaScriptSerializer();
            serializer.MaxJsonLength = int.MaxValue;
            serializer.RecursionLimit = 256;
        }

        public LandmarkFrame ParseFile(string path)
        {
            if (string.IsNullOrWhiteSpace(path)) throw new ArgumentNullException("path");
            string json = File.ReadAllText(path);
            LandmarkFrame frame = ParseJson(json);
            frame.TimeSeconds = TryReadFrameTime(Path.GetFileNameWithoutExtension(path));
            return frame;
        }

        public LandmarkFrame ParseJson(string json)
        {
            object rootObject = serializer.DeserializeObject(json);
            IDictionary<string, object> root = AsDictionary(rootObject);
            if (root == null) throw new InvalidDataException("JSON root must be an object.");

            IDictionary<string, object> person = ResolvePerson(root);
            if (person == null) throw new InvalidDataException("The JSON does not contain a people object.");

            bool use3D = HasValues(person, "pose_keypoints_3d", 4);
            int stride = use3D ? 4 : 3;
            string suffix = use3D ? "_3d" : "_2d";

            LandmarkPoint[] poseAll = ParsePoints(GetValue(person, "pose_keypoints" + suffix), stride, 25);
            LandmarkPoint[] leftHand = ParsePoints(GetValue(person, "hand_left_keypoints" + suffix), stride, 21);
            LandmarkPoint[] rightHand = ParsePoints(GetValue(person, "hand_right_keypoints" + suffix), stride, 21);
            LandmarkPoint[] face = ParsePoints(GetValue(person, "face_keypoints" + suffix), stride, 70);

            LandmarkFrame frame = new LandmarkFrame();
            for (int i = 0; i < PoseIndices.Length; i++)
                frame.BodyHands[i] = SafePoint(poseAll, PoseIndices[i]);
            for (int i = 0; i < 21; i++)
            {
                frame.BodyHands[LandmarkFrame.PoseCount + i] = SafePoint(leftHand, i);
                frame.BodyHands[LandmarkFrame.PoseCount + LandmarkFrame.HandCount + i] = SafePoint(rightHand, i);
            }
            frame.Face = face;
            return frame;
        }

        private static IDictionary<string, object> ResolvePerson(IDictionary<string, object> root)
        {
            object people;
            if (!root.TryGetValue("people", out people)) return null;

            IDictionary<string, object> direct = AsDictionary(people);
            if (direct != null) return direct;

            IList list = people as IList;
            if (list != null && list.Count > 0) return AsDictionary(list[0]);
            return null;
        }

        private static LandmarkPoint[] ParsePoints(object value, int stride, int expected)
        {
            IList values = value as IList;
            LandmarkPoint[] result = new LandmarkPoint[expected];
            for (int i = 0; i < expected; i++) result[i] = new LandmarkPoint();
            if (values == null) return result;

            int count = Math.Min(expected, values.Count / stride);
            for (int i = 0; i < count; i++)
            {
                int offset = i * stride;
                double x = ToDouble(values[offset]);
                double y = ToDouble(values[offset + 1]);
                double z = stride == 4 ? ToDouble(values[offset + 2]) : 0.0;
                double confidence = ToDouble(values[offset + stride - 1]);
                result[i] = new LandmarkPoint(x, y, z, confidence);
            }
            return result;
        }

        private static LandmarkPoint SafePoint(LandmarkPoint[] points, int index)
        {
            if (points == null || index < 0 || index >= points.Length) return new LandmarkPoint();
            return points[index] == null ? new LandmarkPoint() : points[index];
        }

        private static bool HasValues(IDictionary<string, object> dictionary, string key, int minimum)
        {
            IList list = GetValue(dictionary, key) as IList;
            return list != null && list.Count >= minimum;
        }

        private static object GetValue(IDictionary<string, object> dictionary, string key)
        {
            object value;
            return dictionary.TryGetValue(key, out value) ? value : null;
        }

        private static IDictionary<string, object> AsDictionary(object value)
        {
            return value as IDictionary<string, object>;
        }

        private static double ToDouble(object value)
        {
            if (value == null) return 0.0;
            try { return Convert.ToDouble(value, CultureInfo.InvariantCulture); }
            catch (Exception) { return 0.0; }
        }

        private static double TryReadFrameTime(string fileName)
        {
            int marker = fileName.LastIndexOf('_');
            long frame;
            if (marker >= 0 && long.TryParse(fileName.Substring(marker + 1).Replace("_keypoints", ""), out frame))
                return frame / 30.0;

            string digits = string.Empty;
            for (int i = fileName.Length - 1; i >= 0 && char.IsDigit(fileName[i]); i--)
                digits = fileName[i] + digits;
            return long.TryParse(digits, out frame) ? frame / 30.0 : 0.0;
        }
    }
}
