using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using SignBridge.Core.Data;
using SignBridge.Core.Models;

namespace SignBridge.Core.Streaming
{
    public sealed class FrameReceivedEventArgs : EventArgs
    {
        public LandmarkFrame Frame { get; private set; }
        public FrameReceivedEventArgs(LandmarkFrame frame) { Frame = frame; }
    }

    public sealed class SourceErrorEventArgs : EventArgs
    {
        public Exception Error { get; private set; }
        public SourceErrorEventArgs(Exception error) { Error = error; }
    }

    public sealed class UdpLandmarkSource : IDisposable
    {
        private UdpClient client;
        private Thread worker;
        private volatile bool running;
        private readonly AiHubJsonParser parser;

        public event EventHandler<FrameReceivedEventArgs> FrameReceived;
        public event EventHandler<SourceErrorEventArgs> Error;

        public bool IsRunning { get { return running; } }

        public UdpLandmarkSource()
        {
            parser = new AiHubJsonParser();
        }

        public void Start(int port)
        {
            if (running) return;
            client = new UdpClient(new IPEndPoint(IPAddress.Loopback, port));
            running = true;
            worker = new Thread(ReceiveLoop);
            worker.IsBackground = true;
            worker.Name = "SignBridge UDP landmark receiver";
            worker.Start();
        }

        public void Stop()
        {
            running = false;
            if (client != null) client.Close();
            if (worker != null && worker.IsAlive) worker.Join(500);
            client = null;
            worker = null;
        }

        private void ReceiveLoop()
        {
            IPEndPoint endpoint = new IPEndPoint(IPAddress.Loopback, 0);
            while (running)
            {
                try
                {
                    byte[] bytes = client.Receive(ref endpoint);
                    LandmarkFrame frame = parser.ParseJson(Encoding.UTF8.GetString(bytes));
                    EventHandler<FrameReceivedEventArgs> handler = FrameReceived;
                    if (handler != null) handler(this, new FrameReceivedEventArgs(frame));
                }
                catch (ObjectDisposedException) { break; }
                catch (SocketException) { if (!running) break; RaiseError(new InvalidOperationException("UDP landmark stream stopped.")); }
                catch (Exception ex) { RaiseError(ex); }
            }
        }

        private void RaiseError(Exception error)
        {
            EventHandler<SourceErrorEventArgs> handler = Error;
            if (handler != null) handler(this, new SourceErrorEventArgs(error));
        }

        public void Dispose()
        {
            Stop();
        }
    }
}
