using System;
using System.Collections.Generic;

namespace SignBridge.Core.Models
{
    [Serializable]
    public sealed class SignSequence
    {
        public string Label { get; set; }
        public string GroupId { get; set; }
        public string SourcePath { get; set; }
        public List<LandmarkFrame> Frames { get; set; }

        public SignSequence()
        {
            Label = string.Empty;
            GroupId = string.Empty;
            SourcePath = string.Empty;
            Frames = new List<LandmarkFrame>();
        }
    }
}
