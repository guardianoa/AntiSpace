using System;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using SignBridge.Core.Models;
using SignBridge.Core.Processing;

namespace SignBridge.App
{
    internal sealed class AvatarRenderer
    {
        private static readonly int[,] PoseEdges = { { 0, 1 }, { 1, 2 }, { 2, 3 }, { 3, 4 }, { 1, 5 }, { 5, 6 }, { 6, 7 }, { 2, 5 } };
        private static readonly int[,] HandEdges =
        {
            {0,1},{1,2},{2,3},{3,4}, {0,5},{5,6},{6,7},{7,8},
            {0,9},{9,10},{10,11},{11,12}, {0,13},{13,14},{14,15},{15,16},
            {0,17},{17,18},{18,19},{19,20}
        };

        private readonly Viewport3D viewport;
        private readonly KeypointProcessor processor;
        private readonly MeshGeometry3D sphereMesh;
        private readonly MeshGeometry3D cylinderMesh;

        public AvatarRenderer(Viewport3D viewport)
        {
            this.viewport = viewport;
            processor = new KeypointProcessor();
            sphereMesh = CreateSphere(10, 14);
            cylinderMesh = CreateCylinder(14);
            viewport.Camera = new PerspectiveCamera(new Point3D(0, 0.15, 4.6), new Vector3D(0, -0.15, -4.6), new Vector3D(0, 1, 0), 34);
            Render(CreateNeutralFrame());
        }

        public void Render(LandmarkFrame rawFrame)
        {
            if (rawFrame == null) return;
            LandmarkFrame frame = processor.Normalize(rawFrame);
            Model3DGroup scene = new Model3DGroup();
            scene.Children.Add(new AmbientLight(Color.FromRgb(82, 92, 125)));
            scene.Children.Add(new DirectionalLight(Colors.White, new Vector3D(-0.5, -1, -2)));
            scene.Children.Add(new DirectionalLight(Color.FromRgb(110, 150, 255), new Vector3D(1, 0.2, -1)));

            AddEdges(scene, frame.BodyHands, PoseEdges, 0, Color.FromRgb(110, 155, 255), 0.035);
            AddEdges(scene, frame.BodyHands, HandEdges, LandmarkFrame.PoseCount, Color.FromRgb(72, 220, 170), 0.015);
            AddEdges(scene, frame.BodyHands, HandEdges, LandmarkFrame.PoseCount + LandmarkFrame.HandCount, Color.FromRgb(255, 170, 70), 0.015);

            for (int i = 0; i < frame.BodyHands.Length; i++)
            {
                if (!frame.BodyHands[i].IsValid) continue;
                double radius = i < LandmarkFrame.PoseCount ? 0.055 : 0.026;
                Color color = i < LandmarkFrame.PoseCount ? Color.FromRgb(215, 225, 255) :
                    (i < LandmarkFrame.PoseCount + LandmarkFrame.HandCount ? Color.FromRgb(72, 235, 176) : Color.FromRgb(255, 177, 75));
                scene.Children.Add(Sphere(Map(frame.BodyHands[i]), radius, color));
            }
            AddFace(scene, frame, rawFrame.Face);

            ModelVisual3D visual = new ModelVisual3D();
            visual.Content = scene;
            viewport.Children.Clear();
            viewport.Children.Add(visual);
        }

        private void AddFace(Model3DGroup scene, LandmarkFrame frame, LandmarkPoint[] rawFace)
        {
            Point3D head = frame.BodyHands[0].IsValid ? Map(frame.BodyHands[0]) : new Point3D(0, 0.85, 0);
            scene.Children.Add(Sphere(head, 0.17, Color.FromRgb(232, 196, 170)));
            double leftEyeOpen = EyeOpen(rawFace, 37, 41, 38, 40);
            double rightEyeOpen = EyeOpen(rawFace, 43, 47, 44, 46);
            double mouthOpen = Ratio(rawFace, 62, 66, 48, 54);
            double eyeLeftSize = 0.017 + Math.Min(0.025, leftEyeOpen * 0.12);
            double eyeRightSize = 0.017 + Math.Min(0.025, rightEyeOpen * 0.12);
            scene.Children.Add(Sphere(new Point3D(head.X - 0.06, head.Y + 0.035, head.Z + 0.155), eyeLeftSize, Colors.Black));
            scene.Children.Add(Sphere(new Point3D(head.X + 0.06, head.Y + 0.035, head.Z + 0.155), eyeRightSize, Colors.Black));
            double gap = 0.008 + Math.Min(0.055, mouthOpen * 0.15);
            Point3D mouthLeft = new Point3D(head.X - 0.055, head.Y - 0.07 - gap * 0.5, head.Z + 0.158);
            Point3D mouthRight = new Point3D(head.X + 0.055, head.Y - 0.07 - gap * 0.5, head.Z + 0.158);
            scene.Children.Add(Cylinder(mouthLeft, mouthRight, 0.012, Color.FromRgb(145, 42, 65)));
            if (gap > 0.015)
                scene.Children.Add(Cylinder(new Point3D(mouthLeft.X, mouthLeft.Y - gap, mouthLeft.Z), new Point3D(mouthRight.X, mouthRight.Y - gap, mouthRight.Z), 0.009, Color.FromRgb(145, 42, 65)));
        }

        private void AddEdges(Model3DGroup scene, LandmarkPoint[] points, int[,] edges, int offset, Color color, double radius)
        {
            for (int i = 0; i < edges.GetLength(0); i++)
            {
                int a = offset + edges[i, 0], b = offset + edges[i, 1];
                if (a >= points.Length || b >= points.Length || !points[a].IsValid || !points[b].IsValid) continue;
                scene.Children.Add(Cylinder(Map(points[a]), Map(points[b]), radius, color));
            }
        }

        private GeometryModel3D Sphere(Point3D center, double radius, Color color)
        {
            GeometryModel3D model = new GeometryModel3D(sphereMesh, Material(color));
            Transform3DGroup transform = new Transform3DGroup();
            transform.Children.Add(new ScaleTransform3D(radius, radius, radius));
            transform.Children.Add(new TranslateTransform3D(center.X, center.Y, center.Z));
            model.Transform = transform;
            return model;
        }

        private GeometryModel3D Cylinder(Point3D from, Point3D to, double radius, Color color)
        {
            Vector3D direction = to - from;
            double length = direction.Length;
            if (length < 1e-8) return Sphere(from, radius, color);
            direction.Normalize();
            Vector3D yAxis = new Vector3D(0, 1, 0);
            Vector3D axis = Vector3D.CrossProduct(yAxis, direction);
            double dot = Math.Max(-1.0, Math.Min(1.0, Vector3D.DotProduct(yAxis, direction)));
            double angle = Math.Acos(dot) * 180.0 / Math.PI;
            if (axis.Length < 1e-8) axis = new Vector3D(1, 0, 0); else axis.Normalize();
            Point3D middle = new Point3D((from.X + to.X) * 0.5, (from.Y + to.Y) * 0.5, (from.Z + to.Z) * 0.5);

            Transform3DGroup transform = new Transform3DGroup();
            transform.Children.Add(new ScaleTransform3D(radius, length, radius));
            transform.Children.Add(new RotateTransform3D(new AxisAngleRotation3D(axis, angle)));
            transform.Children.Add(new TranslateTransform3D(middle.X, middle.Y, middle.Z));
            GeometryModel3D model = new GeometryModel3D(cylinderMesh, Material(color));
            model.Transform = transform;
            return model;
        }

        private static Material Material(Color color)
        {
            DiffuseMaterial material = new DiffuseMaterial(new SolidColorBrush(color));
            return material;
        }

        private static Point3D Map(LandmarkPoint point)
        {
            return new Point3D(point.X * 1.15, -point.Y * 1.15, -point.Z * 1.15);
        }

        private static double EyeOpen(LandmarkPoint[] face, int a, int b, int c, int d)
        {
            return (Distance(face, a, b) + Distance(face, c, d)) * 0.5 / Math.Max(Distance(face, 36, 45), 1e-8);
        }

        private static double Ratio(LandmarkPoint[] face, int a, int b, int c, int d)
        {
            return Distance(face, a, b) / Math.Max(Distance(face, c, d), 1e-8);
        }

        private static double Distance(LandmarkPoint[] points, int a, int b)
        {
            if (points == null || a >= points.Length || b >= points.Length || !points[a].IsValid || !points[b].IsValid) return 0.0;
            double x = points[a].X - points[b].X, y = points[a].Y - points[b].Y;
            return Math.Sqrt(x * x + y * y);
        }

        private static MeshGeometry3D CreateSphere(int latitude, int longitude)
        {
            MeshGeometry3D mesh = new MeshGeometry3D();
            for (int y = 0; y <= latitude; y++)
            {
                double phi = Math.PI * y / latitude;
                for (int x = 0; x <= longitude; x++)
                {
                    double theta = 2.0 * Math.PI * x / longitude;
                    Vector3D normal = new Vector3D(Math.Sin(phi) * Math.Cos(theta), Math.Cos(phi), Math.Sin(phi) * Math.Sin(theta));
                    mesh.Positions.Add(new Point3D(normal.X, normal.Y, normal.Z)); mesh.Normals.Add(normal);
                }
            }
            for (int y = 0; y < latitude; y++) for (int x = 0; x < longitude; x++)
            {
                int a = y * (longitude + 1) + x, b = a + longitude + 1;
                mesh.TriangleIndices.Add(a); mesh.TriangleIndices.Add(b); mesh.TriangleIndices.Add(a + 1);
                mesh.TriangleIndices.Add(a + 1); mesh.TriangleIndices.Add(b); mesh.TriangleIndices.Add(b + 1);
            }
            return mesh;
        }

        private static MeshGeometry3D CreateCylinder(int segments)
        {
            MeshGeometry3D mesh = new MeshGeometry3D();
            for (int i = 0; i <= segments; i++)
            {
                double angle = i * Math.PI * 2.0 / segments;
                double x = Math.Cos(angle), z = Math.Sin(angle);
                mesh.Positions.Add(new Point3D(x, -0.5, z)); mesh.Normals.Add(new Vector3D(x, 0, z));
                mesh.Positions.Add(new Point3D(x, 0.5, z)); mesh.Normals.Add(new Vector3D(x, 0, z));
            }
            for (int i = 0; i < segments; i++)
            {
                int a = i * 2;
                mesh.TriangleIndices.Add(a); mesh.TriangleIndices.Add(a + 1); mesh.TriangleIndices.Add(a + 2);
                mesh.TriangleIndices.Add(a + 2); mesh.TriangleIndices.Add(a + 1); mesh.TriangleIndices.Add(a + 3);
            }
            return mesh;
        }

        private static LandmarkFrame CreateNeutralFrame()
        {
            LandmarkFrame frame = new LandmarkFrame();
            double[,] pose = { { 0, -0.7, 0 }, { 0, -0.35, 0 }, { -0.4, -0.3, 0 }, { -0.58, 0.05, 0 }, { -0.45, 0.42, 0 }, { 0.4, -0.3, 0 }, { 0.58, 0.05, 0 }, { 0.45, 0.42, 0 } };
            for (int i = 0; i < 8; i++) frame.BodyHands[i] = new LandmarkPoint(pose[i, 0], pose[i, 1], pose[i, 2], 1);
            for (int hand = 0; hand < 2; hand++) for (int i = 0; i < 21; i++)
            {
                double side = hand == 0 ? 1 : -1;
                double x = side * (0.45 + (i % 4) * 0.025), y = 0.42 + (i / 4) * 0.035;
                frame.BodyHands[8 + hand * 21 + i] = new LandmarkPoint(x, y, 0, 1);
            }
            return frame;
        }
    }
}
