using System.Windows;

namespace SignBridge.App
{
    public partial class App : Application
    {
    }
}
