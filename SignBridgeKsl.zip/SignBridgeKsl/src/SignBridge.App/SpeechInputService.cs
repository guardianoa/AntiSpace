using System;
using System.Globalization;
using System.Linq;
using System.Speech.Recognition;

namespace SignBridge.App
{
    internal sealed class TextRecognizedEventArgs : EventArgs
    {
        public string Text { get; private set; }
        public TextRecognizedEventArgs(string text) { Text = text; }
    }

    internal sealed class SpeechInputService : IDisposable
    {
        private SpeechRecognitionEngine engine;
        public event EventHandler<TextRecognizedEventArgs> TextRecognized;
        public bool IsListening { get; private set; }

        public void Start()
        {
            if (IsListening) return;
            RecognizerInfo korean = SpeechRecognitionEngine.InstalledRecognizers()
                .FirstOrDefault(delegate(RecognizerInfo info) { return info.Culture.Name.Equals("ko-KR", StringComparison.OrdinalIgnoreCase); });
            if (korean == null) throw new InvalidOperationException("Windows 한국어 음성 인식 언어 팩이 설치되어 있지 않습니다.");

            engine = new SpeechRecognitionEngine(korean.Id);
            engine.LoadGrammar(new DictationGrammar());
            engine.SetInputToDefaultAudioDevice();
            engine.SpeechRecognized += Engine_SpeechRecognized;
            engine.RecognizeAsync(RecognizeMode.Multiple);
            IsListening = true;
        }

        public void Stop()
        {
            if (engine != null)
            {
                try { engine.RecognizeAsyncCancel(); } catch (InvalidOperationException) { }
                engine.SpeechRecognized -= Engine_SpeechRecognized;
                engine.Dispose();
                engine = null;
            }
            IsListening = false;
        }

        private void Engine_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
            if (e.Result == null || e.Result.Confidence < 0.45 || string.IsNullOrWhiteSpace(e.Result.Text)) return;
            EventHandler<TextRecognizedEventArgs> handler = TextRecognized;
            if (handler != null) handler(this, new TextRecognizedEventArgs(e.Result.Text));
        }

        public void Dispose() { Stop(); }
    }
}
