using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Threading;
using Microsoft.Win32;
using SignBridge.Core.Data;
using SignBridge.Core.Models;
using SignBridge.Core.Processing;
using SignBridge.Core.Recognition;
using SignBridge.Core.Streaming;
using SignBridge.Core.Translation;

namespace SignBridge.App
{
    public partial class MainWindow : Window
    {
        private readonly DatasetLoader datasetLoader;
        private readonly DispatcherTimer playbackTimer;
        private readonly object liveSync;
        private List<LandmarkFrame> playbackFrames;
        private int playbackIndex;
        private bool livePredictionRunning;
        private PrototypeRecognizer recognizer;
        private UdpLandmarkSource udpSource;
        private SpeechInputService speech;
        private SkeletonRenderer skeleton;
        private AvatarRenderer avatar;
        private GlossTranslator glossTranslator;
        private MotionLibrary motionLibrary;
        private TrainingWorkspace workspace;
        private MotionSegmenter liveSegmenter;

        public MainWindow()
        {
            InitializeComponent();
            datasetLoader = new DatasetLoader();
            playbackFrames = new List<LandmarkFrame>();
            liveSync = new object();
            playbackTimer = new DispatcherTimer(DispatcherPriority.Render);
            playbackTimer.Interval = TimeSpan.FromMilliseconds(1000.0 / 30.0);
            playbackTimer.Tick += PlaybackTimer_Tick;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            skeleton = new SkeletonRenderer(SignerCanvas);
            avatar = new AvatarRenderer(AvatarViewport);
            workspace = new TrainingWorkspace(TrainingWorkspace.DefaultRootPath);
            workspace.EnsureCreated();
            liveSegmenter = new MotionSegmenter();
            glossTranslator = new GlossTranslator();
            string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
            glossTranslator.LoadRules(Path.Combine(baseDirectory, "config", "gloss-rules.csv"));
            motionLibrary = new MotionLibrary(workspace.MotionsPath);
            speech = new SpeechInputService();
            speech.TextRecognized += Speech_TextRecognized;
            TryLoadWorkspaceModel();
            Status((workspace.HasPendingTrainingData() ? "새 학습 데이터가 있습니다. '모델 업데이트'를 누르세요. · " : string.Empty) +
                   "학습 데이터 폴더: " + workspace.TrainingPath);
        }

        private void OpenClip_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "AI Hub keypoint JSON|*_keypoints.json|JSON|*.json";
            dialog.Title = "클립의 아무 키포인트 프레임 하나를 선택하세요";
            if (dialog.ShowDialog(this) != true) return;
            try
            {
                string directory = Path.GetDirectoryName(dialog.FileName);
                SignSequence sequence = datasetLoader.LoadClipDirectory(directory, Path.GetFileName(directory));
                StartPlayback(sequence.Frames);
                InputModeText.Text = "파일 · " + Path.GetFileName(directory) + " · " + sequence.Frames.Count + "프레임";
                Status("좌표 클립을 불러왔습니다. 재생 후 '현재 클립 인식'을 누를 수 있습니다.");
            }
            catch (Exception ex) { ShowError(ex); }
        }

        private void OpenModel_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "SignBridge model|*.sbm|JSON|*.json";
            if (dialog.ShowDialog(this) != true) return;
            try
            {
                recognizer = new PrototypeRecognizer(PrototypeRecognizer.Load(dialog.FileName));
                ModelStatusText.Text = recognizer.Model.Classes.Count + "개 수어 · " + Path.GetFileName(dialog.FileName);
                Status("인식 모델을 불러왔습니다.");
            }
            catch (Exception ex) { ShowError(ex); }
        }

        private void TrainModel_Click(object sender, RoutedEventArgs e)
        {
            Status("추가된 전체 좌표를 검사하고 모델을 업데이트하는 중입니다.");
            ThreadPool.QueueUserWorkItem(delegate
            {
                try
                {
                    WorkspaceUpdateResult result = workspace.UpdateModel(60, 12);
                    Dispatcher.BeginInvoke(new Action(delegate
                    {
                        recognizer = new PrototypeRecognizer(result.Model);
                        ModelStatusText.Text = result.Model.Classes.Count + "개 수어 · 자동 모델";
                        string warnings = string.Join(" ", result.DataWarnings.Concat(result.Training.Warnings).ToArray());
                        Status("모델 업데이트 완료: " + result.Training.SequenceCount + "개 클립, " +
                               result.Training.ClassCount + "개 수어, 교차검증 " + result.Evaluation.Accuracy.ToString("P1") +
                               (warnings.Length == 0 ? string.Empty : " · 경고: " + warnings));
                    }));
                }
                catch (Exception ex) { Dispatcher.BeginInvoke(new Action(delegate { ShowError(ex); })); }
            });
        }

        private void OpenTrainingFolder_Click(object sender, RoutedEventArgs e)
        {
            workspace.EnsureCreated();
            OpenFolder(workspace.TrainingPath);
            Status("이 폴더에 <수어명>/<클립>/*_keypoints.json 구조로 계속 추가하세요.");
        }

        private void OpenMotionFolder_Click(object sender, RoutedEventArgs e)
        {
            workspace.EnsureCreated();
            OpenFolder(workspace.MotionsPath);
            Status("이 폴더에 <글로스>/<클립>/*_keypoints.json 구조로 검증된 아바타 모션을 추가하세요.");
        }

        private void Recognize_Click(object sender, RoutedEventArgs e)
        {
            if (recognizer == null) { Status("먼저 모델을 열거나 데이터를 학습하세요."); return; }
            if (playbackFrames.Count == 0) { Status("먼저 좌표 클립을 여세요."); return; }
            try { ShowRecognition(recognizer.Predict(playbackFrames)); }
            catch (Exception ex) { ShowError(ex); }
        }

        private void ToggleUdp_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (udpSource != null && udpSource.IsRunning)
                {
                    udpSource.Stop(); UdpButton.Content = "UDP 시작"; InputModeText.Text = "UDP 중지";
                    return;
                }
                udpSource = new UdpLandmarkSource();
                udpSource.FrameReceived += Udp_FrameReceived;
                udpSource.Error += Udp_Error;
                udpSource.Start(50505);
                liveSegmenter.Reset();
                UdpButton.Content = "UDP 중지"; InputModeText.Text = "실시간 UDP · 127.0.0.1:50505";
                Status("AI Hub 형식 JSON 프레임을 UDP 50505 포트로 기다리는 중입니다.");
            }
            catch (Exception ex) { ShowError(ex); }
        }

        private void Udp_FrameReceived(object sender, FrameReceivedEventArgs e)
        {
            List<LandmarkFrame> completed;
            lock (liveSync)
            {
                completed = liveSegmenter.AddFrame(e.Frame);
            }
            Dispatcher.BeginInvoke(new Action(delegate
            {
                RenderFrame(e.Frame);
                InputModeText.Text = liveSegmenter.IsRecording ? "실시간 UDP · 수어 동작 기록 중" : "실시간 UDP · 동작 대기";
            }));
            if (completed != null) QueueLivePrediction(completed);
        }

        private void QueueLivePrediction(List<LandmarkFrame> snapshot)
        {
            lock (liveSync)
            {
                if (recognizer == null || livePredictionRunning) return;
                livePredictionRunning = true;
            }
            ThreadPool.QueueUserWorkItem(delegate
            {
                try
                {
                    RecognitionResult result = recognizer.Predict(snapshot);
                    Dispatcher.BeginInvoke(new Action(delegate { ShowRecognition(result); }));
                }
                catch (Exception ex) { Dispatcher.BeginInvoke(new Action(delegate { Status("실시간 인식 오류: " + ex.Message); })); }
                finally { lock (liveSync) livePredictionRunning = false; }
            });
        }

        private void Udp_Error(object sender, SourceErrorEventArgs e)
        {
            Dispatcher.BeginInvoke(new Action(delegate { Status("UDP 오류: " + e.Error.Message); }));
        }

        private void PlayText_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string[] available = motionLibrary.AvailableGlosses;
                if (available.Length == 0)
                {
                    Status("motions/<글로스>/<클립 JSON> 모션 라이브러리가 비어 있습니다. 검증된 한국수어 모션을 먼저 등록하세요.");
                    return;
                }
                string[] gloss = glossTranslator.Translate(KoreanInput.Text, available);
                if (gloss.Length == 0) { Status("등록된 모션으로 표현할 수 없는 문장입니다."); return; }
                List<LandmarkFrame> frames = motionLibrary.Compose(gloss, 8);
                StartPlayback(frames);
                Status("글로스: " + string.Join(" → ", gloss));
            }
            catch (Exception ex) { ShowError(ex); }
        }

        private void ToggleSpeech_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (speech.IsListening) { speech.Stop(); SpeechButton.Content = "음성 입력 시작"; Status("음성 입력을 중지했습니다."); }
                else { speech.Start(); SpeechButton.Content = "음성 입력 중지"; Status("한국어 음성을 듣고 있습니다."); }
            }
            catch (Exception ex) { ShowError(ex); }
        }

        private void Speech_TextRecognized(object sender, TextRecognizedEventArgs e)
        {
            Dispatcher.BeginInvoke(new Action(delegate { KoreanInput.Text = e.Text; Status("음성 인식: " + e.Text); }));
        }

        private void StopPlayback_Click(object sender, RoutedEventArgs e)
        {
            playbackTimer.Stop();
            Status("3D 모션 재생을 중지했습니다.");
        }

        private void StartPlayback(IEnumerable<LandmarkFrame> frames)
        {
            playbackFrames = frames.Select(delegate(LandmarkFrame f) { return f.Clone(); }).ToList();
            playbackIndex = 0;
            if (playbackFrames.Count > 0) { RenderFrame(playbackFrames[0]); playbackTimer.Start(); }
        }

        private void PlaybackTimer_Tick(object sender, EventArgs e)
        {
            if (playbackIndex >= playbackFrames.Count) { playbackTimer.Stop(); return; }
            RenderFrame(playbackFrames[playbackIndex++]);
        }

        private void RenderFrame(LandmarkFrame frame)
        {
            skeleton.Render(frame);
            avatar.Render(frame);
        }

        private void ShowRecognition(RecognitionResult result)
        {
            RecognitionText.Text = result.Label;
            ConfidenceText.Text = "신뢰도 " + result.Confidence.ToString("P1") + " · 거리 " + result.Distance.ToString("F5") +
                (result.Rejected ? " · " + result.Reason : string.Empty);
            if (!result.Rejected) Status("수어 인식: " + result.Label);
        }

        private void Status(string message) { StatusText.Text = message; }
        private void ShowError(Exception ex) { Status("오류: " + ex.Message); }

        private void TryLoadWorkspaceModel()
        {
            try
            {
                PrototypeModel model = workspace.TryLoadCurrentModel();
                if (model == null) { ModelStatusText.Text = "자동 모델 없음"; return; }
                recognizer = new PrototypeRecognizer(model);
                ModelStatusText.Text = model.Classes.Count + "개 수어 · 자동 로드";
            }
            catch (Exception ex)
            {
                ModelStatusText.Text = "모델 로드 오류";
                Status("기존 모델을 불러오지 못했습니다: " + ex.Message);
            }
        }

        private static void OpenFolder(string path)
        {
            Process.Start(new ProcessStartInfo { FileName = path, UseShellExecute = true });
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            playbackTimer.Stop();
            if (udpSource != null) udpSource.Dispose();
            if (speech != null) speech.Dispose();
        }
    }
}
