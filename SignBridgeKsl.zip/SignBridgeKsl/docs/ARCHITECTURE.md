# 아키텍처

```mermaid
flowchart LR
    Camera[카메라] --> Tracker[손·상체·얼굴 랜드마크 추출]
    Json[AI Hub JSON] --> Parser[C# JSON 파서]
    Tracker --> Udp[로컬 UDP 50505]
    Udp --> Segment[움직임 시작·정지 구간 분리]
    Segment --> Pre[결측 보정·정규화·리샘플링]
    Parser --> Pre
    Pre --> Recognizer[좌표 시퀀스 인식기]
    Recognizer --> Reject{미등록/모호성 판정}
    Reject --> Text[한국어 텍스트·TTS]

    Speech[한국어 음성·텍스트] --> Gloss[한국수어 글로스 변환]
    Gloss --> Library[검증된 3D 모션 라이브러리]
    Library --> Blend[전환·리타기팅·표정]
    Blend --> Avatar[3D 휴머노이드 아바타]
```

## 프로젝트

- `SignBridge.Core`: 데이터 모델, AI Hub 파서, 전처리, 동작 구간 분리, 반복 업데이트 저장소, 학습/추론, 글로스, UDP
- `SignBridge.App`: 이분할 WPF UI, 2D 좌표 확인, 3D 렌더러, 음성 입력
- `SignBridge.Cli`: 데이터 검사, 학습, 예측, leave-one-clip-out 평가
- `SignBridge.Tests`: 패서·정규화·리샘플링·모델 저장/인식 회귀 테스트

## 좌표 스키마

프레임당 특징은 총 210개입니다.

- 상체 8 + 양손 42 = 50점 × XYZ = 150
- 각 관절 검출 신뢰도 = 50
- 얼굴 비수지 특징 = 10
  - 좌/우 눈 열림
  - 입 열림과 입 너비
  - 좌/우 눈썹 높이
  - 머리 기울기
  - 코의 수평 위치
  - 입꼬리 기울기
  - 눈썹 비대칭

좌표는 두 어깨 중점을 원점으로, 어깨 너비를 1로 정규화합니다. 이는 위치와 사람 크기 변화는 줄이지만 카메라 시점, 손 가림, 체형, 방언, 개인별 표현 차이를 없애지는 못합니다.

## 모델 교체 지점

현재 `PrototypeRecognizer`는 DTW 최근접 예제를 사용합니다. 데이터가 충분해지면 다음 계약만 유지한 채 ONNX 추론기로 교체합니다.

```text
입력: [batch, time, 210]
출력: 프레임별 blank/글로스 확률 또는 문장 토큰 확률
메타: 스키마 버전, 라벨 사전, 정규화 방식, 프레임 속도, 거절 임계값
```

연속수어 인식에는 고정 단어 분류보다 CTC/Transducer/encoder-decoder 구조와 시작·끝 경계 학습이 적합합니다. 제품 모델은 화자 독립 테스트, 실시간 지연, 미등록 동작 거절을 함께 평가해야 합니다.
