$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$solutionPath = Join-Path $projectRoot 'SignBridgeKsl.sln'

$msbuildCandidates = @(
    'C:\Program Files\Microsoft Visual Studio\2022\Community\MSBuild\Current\Bin\MSBuild.exe',
    'C:\Program Files\Microsoft Visual Studio\2022\Professional\MSBuild\Current\Bin\MSBuild.exe',
    'C:\Program Files\Microsoft Visual Studio\2022\Enterprise\MSBuild\Current\Bin\MSBuild.exe',
    'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\MSBuild.exe'
)
$msbuildPath = $msbuildCandidates | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
if (-not $msbuildPath) { throw 'MSBuild를 찾을 수 없습니다. Visual Studio 2022와 .NET Framework 4.8 Developer Pack을 설치하세요.' }

& $msbuildPath $solutionPath /t:Rebuild /p:Configuration=Release /m /verbosity:minimal
if ($LASTEXITCODE -ne 0) { throw "빌드 실패: $LASTEXITCODE" }

$testPath = Join-Path $projectRoot 'tests\SignBridge.Tests\bin\Release\SignBridge.Tests.exe'
& $testPath
if ($LASTEXITCODE -ne 0) { throw "테스트 실패: $LASTEXITCODE" }

Write-Host '빌드와 테스트가 완료되었습니다.'
