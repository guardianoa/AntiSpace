$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$appPath = Join-Path $projectRoot 'src\SignBridge.App\bin\Release\SignBridge.App.exe'
if (-not (Test-Path -LiteralPath $appPath)) {
    & (Join-Path $PSScriptRoot 'build.ps1')
}
Start-Process -FilePath $appPath
