# SignBridge 한국수어 번역 MVP

업로드된 Python 실험 코드를 검토한 뒤, 유지보수 가능한 C# 구조로 새로 작성한 Windows 키오스크 MVP입니다. 단순 문법 변환이 아니라 데이터 파서, 좌표 전처리, 학습/추론, 2D 입력 확인, 3D 아바타, 텍스트·음성 입력을 계층별로 분리했습니다.

## 현재 구현된 범위

- AI Hub OpenPose 형식의 2D/3D 프레임 JSON 읽기
- 상체 8점 + 양손 42점 + 얼굴 70점 처리
- 어깨 중심/크기 정규화, 결측 보정, 평활화, 60프레임 리샘플링
- 눈·입·눈썹·머리 기울기를 포함한 210차원 프레임 특징
- 소량 데이터용 DTW 프로토타입 학습, 후보 신뢰도, 미등록 동작 거절
- 이분할 WPF 키오스크 UI
- 손가락 관절과 간단한 표정을 표시하는 실시간 3D 진단 아바타
- 좌표 파일 재생, 모델 학습/불러오기, UDP 실시간 좌표 입력
- 실시간 좌표에서 움직임 시작·정지를 감지하는 자동 수어 구간 분리
- 고정 사용자 데이터 폴더, 새 데이터 감지, 원클릭 모델 갱신·자동 로드·이전 모델 백업
- 한국어 텍스트→글로스 규칙→등록된 3D 모션 연결
- Windows 한국어 언어 팩이 있을 때 음성 받아쓰기
- CLI와 자동 테스트

## 중요: 포함되지 않은 것

업로드 폴더에는 학습 완료 모델(`.pt`, `.onnx`)과 다중 클래스 학습셋이 없습니다. 제공된 124개 좌표 JSON은 단일 클립이므로 실제 한국수어 인식 모델을 만들 수 없습니다. 또한 검증되지 않은 동작을 한국수어라고 꾸며 넣지 않기 위해 가짜 모델과 가짜 수어 모션을 포함하지 않았습니다.

현재 3D 출력은 좌표·손가락·표정 파이프라인을 확인하는 진단 아바타입니다. 상용 수어 표현용 아바타는 농인 감수를 받은 휴머노이드 리그, 손가락 관절 제한, 얼굴 블렌드셰이프, 시선, 입모양, 몸 방향을 별도로 제작해야 합니다.

## 실행

가장 간단한 실행 파일은 `dist/SignBridge.App/SignBridge.App.exe`입니다. Windows x64와 .NET Framework 4.8이 필요합니다.

소스 빌드는 Visual Studio의 **.NET Framework 4.8 Developer Pack** 또는 Visual Studio 2022 이상을 설치한 뒤 다음을 실행합니다.

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\build.ps1
powershell -ExecutionPolicy Bypass -File .\scripts\run.ps1
```

이 컴퓨터에서는 개발자용 타기팅 팩이 없어 GAC 참조 경고가 발생했지만, 전체 솔루션 빌드와 테스트 실행은 통과했습니다. 제품 개발 브랜치는 [.NET 10 LTS](https://dotnet.microsoft.com/en-us/platform/support/policy)로 이전하는 것을 권장합니다.

## 학습 데이터 구조

프로그램이 처음 실행될 때 다음 고정 저장소를 자동으로 만듭니다.

```text
C:\Users\<Windows 사용자명>\Documents\SignBridgeKslData\
  Training\   계속 추가할 수어 인식 학습 좌표
  Motions\    텍스트→3D 아바타용 검증된 모션
  Models\     자동 생성된 current.sbm과 이전 모델 .bak
  Reports\    가장 최근 학습 결과와 경고
```

새 버전의 프로그램으로 교체해도 이 폴더는 유지됩니다. 앱의 `학습 폴더 열기` 버튼으로 정확한 위치를 열 수 있습니다.

`Training` 안에는 다음 구조로 계속 추가합니다.

```text
Training/
  안녕하세요/
    signer01-session01-clip001/
      ..._000000000000_keypoints.json
      ..._000000000001_keypoints.json
  감사합니다/
    signer02-session01-clip001/
      ..._keypoints.json
```

추가가 끝나면 앱에서 `모델 업데이트`를 누릅니다. 프로그램은 기존 파일과 새 파일을 함께 검사·학습하고, 성공한 경우에만 `Models/current.sbm`을 교체합니다. 이전 정상 모델은 `current.sbm.bak`으로 남으며 다음 실행 때 최신 모델이 자동 로드됩니다.

CLI로 같은 작업을 할 수도 있습니다.

```powershell
SignBridge.Cli.exe workspace
SignBridge.Cli.exe update
SignBridge.Cli.exe train --data C:\ksl\dataset --model C:\ksl\model.sbm
SignBridge.Cli.exe evaluate --data C:\ksl\dataset
SignBridge.Cli.exe predict --model C:\ksl\model.sbm --clip C:\ksl\one-clip
```

데이터 구성과 평가 방법은 [DATASET_GUIDE.md](docs/DATASET_GUIDE.md)를 먼저 읽으세요.

## 실시간 카메라 연결

UI의 `UDP 시작`은 `127.0.0.1:50505`에서 AI Hub `people` 객체와 같은 JSON 프레임을 받습니다. 이를 통해 카메라 랜드마크 추출기를 UI와 독립적으로 교체할 수 있습니다. 프로토콜은 [CAMERA_INTEGRATION.md](docs/CAMERA_INTEGRATION.md)에 있습니다.

상용판에서는 카메라 프레임을 서버로 보내지 않고 키오스크 내부에서 좌표화한 뒤, 원본 영상은 기본적으로 저장하지 않는 구조를 권장합니다.

## 문서

- [프로그램 전체 상세 설명서](README2.md)
- [기존 Python 코드 검토 및 변환 결정](docs/MIGRATION_REVIEW.md)
- [새 C# 구조](docs/ARCHITECTURE.md)
- [데이터 수집·학습·평가](docs/DATASET_GUIDE.md)
- [카메라/UDP 연동](docs/CAMERA_INTEGRATION.md)
- [창업·제품·법적 검토가 필요한 부분](docs/PRODUCT_AND_SAFETY.md)

## 검증 결과

- 솔루션 전체 빌드 성공
- 자동 테스트 6/6 통과
- 업로드 원본 샘플 124프레임 파싱 성공
- 프레임당 유효 상체/손 관절 50/50
- 3D 좌표와 얼굴 랜드마크 70점 확인

이 결과는 **파이프라인 정상 동작**을 뜻하며, 한국수어 인식 정확도를 뜻하지는 않습니다. 정확도는 독립된 화자/촬영 세션 테스트셋으로 측정해야 합니다.
