using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using SignBridge.Core.Data;
using SignBridge.Core.Models;
using SignBridge.Core.Processing;
using SignBridge.Core.Recognition;

namespace SignBridge.Tests
{
    internal static class Program
    {
        private static int passed;

        private static int Main()
        {
            Console.OutputEncoding = Encoding.UTF8;
            try
            {
                Run("AI Hub 3D JSON parser", TestParser);
                Run("normalization invariance", TestNormalization);
                Run("temporal resampling", TestResampling);
                Run("coordinate training and recognition", TestRecognition);
                Run("continuously updated training workspace", TestTrainingWorkspace);
                Run("live motion segmentation", TestMotionSegmentation);
                Console.WriteLine("PASS: " + passed + " tests");
                return 0;
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine("FAIL: " + ex.Message);
                return 1;
            }
        }

        private static void Run(string name, Action test)
        {
            test(); passed++; Console.WriteLine("[PASS] " + name);
        }

        private static void TestParser()
        {
            string json = "{\"people\":{\"pose_keypoints_3d\":" + Flat(25, 4) +
                ",\"hand_left_keypoints_3d\":" + Flat(21, 4) +
                ",\"hand_right_keypoints_3d\":" + Flat(21, 4) +
                ",\"face_keypoints_3d\":" + Flat(70, 4) + "}}";
            LandmarkFrame frame = new AiHubJsonParser().ParseJson(json);
            Assert(frame.BodyHands.Length == 50, "Expected 50 body/hand points.");
            Assert(frame.Face.Length == 70, "Expected 70 face points.");
            Assert(frame.BodyHands.All(delegate(LandmarkPoint p) { return p.IsValid; }), "Parsed points must be valid.");
            Assert(Math.Abs(frame.BodyHands[9].Z - 0.02) < 1e-9, "3D coordinate was not preserved.");
        }

        private static void TestNormalization()
        {
            LandmarkFrame left = SyntheticFrame(0.25, 0.1, 0.0);
            LandmarkFrame right = left.Clone();
            foreach (LandmarkPoint p in right.BodyHands)
            {
                p.X = p.X * 2.0 + 10.0; p.Y = p.Y * 2.0 - 3.0; p.Z = p.Z * 2.0 + 1.0;
            }
            KeypointProcessor processor = new KeypointProcessor();
            double[] a = processor.BuildFeatures(left), b = processor.BuildFeatures(right);
            for (int i = 0; i < 150; i++) Assert(Math.Abs(a[i] - b[i]) < 1e-8, "Normalization changed at feature " + i);
        }

        private static void TestResampling()
        {
            List<LandmarkFrame> frames = new List<LandmarkFrame>();
            frames.Add(SyntheticFrame(0.0, 0.0, 0.0)); frames.Add(SyntheticFrame(1.0, 0.0, 0.1));
            List<LandmarkFrame> output = new KeypointProcessor().Resample(frames, 60);
            Assert(output.Count == 60, "Expected exactly 60 frames.");
            Assert(Math.Abs(output[0].BodyHands[4].X - frames[0].BodyHands[4].X) < 1e-8, "First frame changed.");
            Assert(Math.Abs(output[59].BodyHands[4].X - frames[1].BodyHands[4].X) < 1e-8, "Last frame changed.");
        }

        private static void TestRecognition()
        {
            List<SignSequence> data = new List<SignSequence>();
            for (int sample = 0; sample < 4; sample++)
            {
                data.Add(SyntheticSequence("가로", true, sample * 0.002));
                data.Add(SyntheticSequence("세로", false, sample * 0.002));
            }
            TrainingReport report;
            PrototypeModel model = PrototypeRecognizer.Train(data, 30, 8, out report);
            Assert(report.ClassCount == 2, "Expected two classes.");
            PrototypeRecognizer recognizer = new PrototypeRecognizer(model);
            RecognitionResult result = recognizer.Predict(SyntheticSequence("", true, 0.003).Frames);
            Assert(!result.Rejected, "Known sign should not be rejected: " + result.Reason);
            Assert(result.Label == "가로", "Expected horizontal class, got " + result.Label);

            string path = Path.Combine(Path.GetTempPath(), "signbridge-test-" + Guid.NewGuid().ToString("N") + ".sbm");
            try
            {
                PrototypeRecognizer.Save(model, path);
                RecognitionResult loaded = new PrototypeRecognizer(PrototypeRecognizer.Load(path)).Predict(SyntheticSequence("", false, 0.001).Frames);
                Assert(loaded.Label == "세로", "Saved model changed prediction.");
            }
            finally { if (File.Exists(path)) File.Delete(path); }
        }

        private static void TestTrainingWorkspace()
        {
            string temporaryRoot = Path.Combine(Path.GetTempPath(), "signbridge-workspace-" + Guid.NewGuid().ToString("N"));
            try
            {
                TrainingWorkspace workspace = new TrainingWorkspace(temporaryRoot);
                workspace.EnsureCreated();
                WriteTrainingClass(workspace.TrainingPath, "가로", 0.0);
                WriteTrainingClass(workspace.TrainingPath, "세로", 0.4);
                WorkspaceUpdateResult first = workspace.UpdateModel(12, 4);
                Assert(first.Model.Classes.Count == 2, "First update must contain two labels.");
                Assert(File.Exists(workspace.CurrentModelPath), "Current model was not saved.");
                Assert(File.Exists(workspace.LatestReportPath), "Training report was not saved.");

                WriteTrainingClass(workspace.TrainingPath, "대각", 0.8);
                WorkspaceUpdateResult second = workspace.UpdateModel(12, 4);
                Assert(second.Model.Classes.Count == 3, "Newly added label was not included.");
                Assert(File.Exists(workspace.CurrentModelPath + ".bak"), "Previous model backup was not created.");
            }
            finally
            {
                if (Directory.Exists(temporaryRoot)) Directory.Delete(temporaryRoot, true);
            }
        }

        private static void TestMotionSegmentation()
        {
            MotionSegmenter segmenter = new MotionSegmenter();
            List<LandmarkFrame> completed = null;
            for (int i = 0; i < 10; i++) segmenter.AddFrame(SyntheticFrame(0.1, 0.1, 0));
            for (int i = 0; i < 20; i++) segmenter.AddFrame(SyntheticFrame(0.1 + i * 0.04, 0.1, 0));
            for (int i = 0; i < 15; i++)
            {
                List<LandmarkFrame> result = segmenter.AddFrame(SyntheticFrame(0.86, 0.1, 0));
                if (result != null) completed = result;
            }
            Assert(completed != null, "Motion segment did not close after returning to rest.");
            Assert(completed.Count >= segmenter.MinimumFrames, "Motion segment was too short.");
            Assert(!segmenter.IsRecording, "Segmenter did not return to idle state.");
        }

        private static void WriteTrainingClass(string trainingRoot, string label, double handOffset)
        {
            for (int clip = 0; clip < 2; clip++)
            {
                string clipPath = Path.Combine(trainingRoot, label, "signer" + clip + "-session1-clip1");
                Directory.CreateDirectory(clipPath);
                for (int frame = 0; frame < 3; frame++)
                    File.WriteAllText(Path.Combine(clipPath, frame.ToString("D6") + "_keypoints.json"), JsonFrame(handOffset + frame * 0.01));
            }
        }

        private static string JsonFrame(double handOffset)
        {
            return "{\"people\":{\"pose_keypoints_3d\":" + FlatOffset(25, 4, 0.0) +
                   ",\"hand_left_keypoints_3d\":" + FlatOffset(21, 4, handOffset) +
                   ",\"hand_right_keypoints_3d\":" + FlatOffset(21, 4, -handOffset) +
                   ",\"face_keypoints_3d\":" + FlatOffset(70, 4, 0.0) + "}}";
        }

        private static SignSequence SyntheticSequence(string label, bool horizontal, double noise)
        {
            SignSequence sequence = new SignSequence { Label = label, GroupId = Guid.NewGuid().ToString("N") };
            for (int i = 0; i < 36; i++)
            {
                double t = i / 35.0;
                sequence.Frames.Add(horizontal ? SyntheticFrame(t + noise, 0.15, 0.0) : SyntheticFrame(0.15, t + noise, 0.0));
            }
            return sequence;
        }

        private static LandmarkFrame SyntheticFrame(double wristX, double wristY, double z)
        {
            LandmarkFrame frame = new LandmarkFrame();
            for (int i = 0; i < frame.BodyHands.Length; i++)
                frame.BodyHands[i] = new LandmarkPoint((i % 7) * 0.03, (i / 7) * 0.04, z, 1.0);
            frame.BodyHands[2] = new LandmarkPoint(-0.5, 0, z, 1);
            frame.BodyHands[5] = new LandmarkPoint(0.5, 0, z, 1);
            frame.BodyHands[4] = new LandmarkPoint(wristX, wristY, z, 1);
            frame.BodyHands[29] = new LandmarkPoint(wristX, wristY, z, 1);
            return frame;
        }

        private static string Flat(int count, int stride)
        {
            return FlatOffset(count, stride, 0.0);
        }

        private static string FlatOffset(int count, int stride, double offset)
        {
            List<string> values = new List<string>();
            for (int i = 0; i < count; i++)
            {
                values.Add((i * 0.01 + offset).ToString(System.Globalization.CultureInfo.InvariantCulture));
                values.Add((i * 0.02).ToString(System.Globalization.CultureInfo.InvariantCulture));
                if (stride == 4) values.Add((i * 0.02).ToString(System.Globalization.CultureInfo.InvariantCulture));
                values.Add("1");
            }
            return "[" + string.Join(",", values.ToArray()) + "]";
        }

        private static void Assert(bool condition, string message)
        {
            if (!condition) throw new InvalidOperationException(message);
        }
    }
}
