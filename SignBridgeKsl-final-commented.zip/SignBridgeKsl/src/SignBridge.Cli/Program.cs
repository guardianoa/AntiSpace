using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using SignBridge.Core.Catalog;
using SignBridge.Core.Data;
using SignBridge.Core.Models;
using SignBridge.Core.Recognition;

namespace SignBridge.Cli
{
    // 데이터 검사·학습·예측을 터미널에서 실행하는 유지보수 도구입니다.
    internal static class Program
    {
        private static int Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            try
            {
                if (args.Length == 0) return Usage();
                Dictionary<string, string> options = ParseOptions(args.Skip(1).ToArray());
                string command = args[0].ToLowerInvariant();
                if (command == "inspect") return Inspect(Required(options, "clip"));
                if (command == "train") return Train(Required(options, "data"), Required(options, "model"), IntOption(options, "frames", 60));
                if (command == "predict") return Predict(Required(options, "model"), Required(options, "clip"));
                if (command == "evaluate") return Evaluate(Required(options, "data"), IntOption(options, "frames", 60));
                if (command == "workspace") return ShowWorkspace(Optional(options, "root", TrainingWorkspace.DefaultRootPath));
                if (command == "update") return UpdateWorkspace(Optional(options, "root", TrainingWorkspace.DefaultRootPath));
                return Usage();
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine("오류: " + ex.Message);
                return 1;
            }
        }

        private static int Inspect(string clip)
        {
            SignSequence sequence = new DatasetLoader().LoadClipDirectory(clip, "검사");
            int valid = 0, zValues = 0, face = 0;
            foreach (LandmarkFrame frame in sequence.Frames)
            {
                valid += frame.BodyHands.Count(delegate(LandmarkPoint p) { return p.IsValid; });
                zValues += frame.BodyHands.Count(delegate(LandmarkPoint p) { return p.IsValid && Math.Abs(p.Z) > 1e-8; });
                face = Math.Max(face, frame.Face.Length);
            }
            Console.WriteLine("프레임: " + sequence.Frames.Count);
            Console.WriteLine("프레임당 유효 관절 평균: " + ((double)valid / sequence.Frames.Count).ToString("F1") + "/50");
            Console.WriteLine("좌표: " + (zValues > 0 ? "3D" : "2D"));
            Console.WriteLine("얼굴 랜드마크: " + face);
            return 0;
        }

        private static int Train(string data, string modelPath, int frames)
        {
            DatasetLoader loader = new DatasetLoader();
            List<string> warnings;
            List<SignSequence> sequences = loader.LoadDataset(data, out warnings);
            foreach (string warning in warnings) Console.WriteLine("경고: " + warning);
            TrainingReport report;
            PrototypeModel model = PrototypeRecognizer.Train(sequences, frames, 12, out report);
            PrototypeRecognizer.Save(model, modelPath);
            Console.WriteLine("학습 완료: " + report.SequenceCount + "개 클립, " + report.ClassCount + "개 수어");
            foreach (KeyValuePair<string, int> item in report.SamplesPerClass) Console.WriteLine("  " + item.Key + ": " + item.Value);
            foreach (string warning in report.Warnings) Console.WriteLine("경고: " + warning);
            Console.WriteLine("모델: " + Path.GetFullPath(modelPath));
            return report.ClassCount >= 2 ? 0 : 2;
        }

        private static int Predict(string modelPath, string clip)
        {
            PrototypeRecognizer recognizer = new PrototypeRecognizer(PrototypeRecognizer.Load(modelPath));
            SignSequence sequence = new DatasetLoader().LoadClipDirectory(clip, string.Empty);
            RecognitionResult result = recognizer.Predict(sequence.Frames);
            Console.WriteLine("결과: " + result.Label);
            Console.WriteLine("신뢰도: " + result.Confidence.ToString("P1"));
            Console.WriteLine("거리: " + result.Distance.ToString("F6"));
            if (result.Rejected) Console.WriteLine("거절 사유: " + result.Reason);
            foreach (PredictionAlternative candidate in result.Alternatives)
                Console.WriteLine("  후보 " + candidate.Label + " | " + candidate.Probability.ToString("P1") + " | d=" + candidate.Distance.ToString("F6"));
            return result.Rejected ? 3 : 0;
        }

        private static int Evaluate(string data, int frames)
        {
            List<string> warnings;
            List<SignSequence> sequences = new DatasetLoader().LoadDataset(data, out warnings);
            EvaluationReport report = PrototypeRecognizer.EvaluateLeaveOneOut(sequences, frames);
            Console.WriteLine("Leave-one-clip-out 정확도: " + report.Accuracy.ToString("P2") + " (" + report.Correct + "/" + report.Total + ")");
            foreach (KeyValuePair<string, Dictionary<string, int>> actual in report.Confusion)
                foreach (KeyValuePair<string, int> predicted in actual.Value)
                    Console.WriteLine("  실제=" + actual.Key + " 예측=" + predicted.Key + " 수=" + predicted.Value);
            return 0;
        }

        private static int ShowWorkspace(string root)
        {
            TrainingWorkspace workspace = new TrainingWorkspace(root);
            workspace.EnsureCreated();
            Console.WriteLine("데이터 루트: " + workspace.RootPath);
            Console.WriteLine("코드 매핑 공용 자산(권장): " + workspace.AssetsPath);
            Console.WriteLine("이전 버전 학습 폴더: " + workspace.TrainingPath);
            Console.WriteLine("이전 버전 모션 폴더: " + workspace.MotionsPath);
            Console.WriteLine("코드 매핑 자산: " + workspace.AssetsPath);
            Console.WriteLine("현재 모델: " + workspace.CurrentModelPath);
            return 0;
        }

        private static int UpdateWorkspace(string root)
        {
            TrainingWorkspace workspace = new TrainingWorkspace(root);
            SignCatalog catalog = SignCatalog.CreateDefault();
            SignAssetStore assets = new SignAssetStore(workspace.AssetsPath);
            WorkspaceUpdateResult result = workspace.UpdateMappedModel(catalog, assets, 60, 12);
            Console.WriteLine("모델 업데이트 완료: " + result.Training.SequenceCount + "개 클립, " + result.Training.ClassCount + "개 수어");
            Console.WriteLine("교차검증: " + result.Evaluation.Accuracy.ToString("P2"));
            Console.WriteLine("모델: " + workspace.CurrentModelPath);
            Console.WriteLine("보고서: " + result.ReportPath);
            foreach (string warning in result.DataWarnings.Concat(result.Training.Warnings)) Console.WriteLine("경고: " + warning);
            return 0;
        }

        private static Dictionary<string, string> ParseOptions(string[] args)
        {
            Dictionary<string, string> output = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < args.Length; i++)
            {
                if (!args[i].StartsWith("--")) continue;
                string key = args[i].Substring(2);
                if (i + 1 >= args.Length) throw new ArgumentException("Missing value for --" + key);
                output[key] = args[++i];
            }
            return output;
        }

        private static string Required(Dictionary<string, string> options, string key)
        {
            string value;
            if (!options.TryGetValue(key, out value) || string.IsNullOrWhiteSpace(value))
                throw new ArgumentException("--" + key + " is required.");
            return value;
        }

        private static int IntOption(Dictionary<string, string> options, string key, int fallback)
        {
            string value; int parsed;
            return options.TryGetValue(key, out value) && int.TryParse(value, out parsed) ? parsed : fallback;
        }

        private static string Optional(Dictionary<string, string> options, string key, string fallback)
        {
            string value;
            return options.TryGetValue(key, out value) && !string.IsNullOrWhiteSpace(value) ? value : fallback;
        }

        private static int Usage()
        {
            Console.WriteLine("SignBridge 한국수어 좌표 인식 도구");
            Console.WriteLine("  inspect  --clip <프레임 JSON 폴더>");
            Console.WriteLine("  train    --data <label/clip/frames 구조> --model <model.sbm> [--frames 60]");
            Console.WriteLine("  predict  --model <model.sbm> --clip <프레임 JSON 폴더>");
            Console.WriteLine("  evaluate --data <label/clip/frames 구조> [--frames 60]");
            Console.WriteLine("  workspace [--root <데이터 루트>]  고정 데이터 폴더 생성/표시");
            Console.WriteLine("  update    [--root <데이터 루트>]  추가된 전체 데이터로 자동 모델 갱신");
            return 1;
        }
    }
}
