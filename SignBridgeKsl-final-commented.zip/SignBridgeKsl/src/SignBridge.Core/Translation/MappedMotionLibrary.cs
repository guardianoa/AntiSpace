using System;
using System.Collections.Generic;
using System.Linq;
using SignBridge.Core.Catalog;
using SignBridge.Core.Data;
using SignBridge.Core.Models;

namespace SignBridge.Core.Translation
{
    // Catalog ID에 연결된 좌표 클립을 찾아 단어 사이를 보간해 아바타 재생용으로 만듭니다.
    public sealed class MappedMotionLibrary
    {
        private readonly SignCatalog catalog;
        private readonly SignAssetStore assets;

        public MappedMotionLibrary(SignCatalog catalog, SignAssetStore assets)
        {
            if (catalog == null) throw new ArgumentNullException("catalog");
            if (assets == null) throw new ArgumentNullException("assets");
            this.catalog = catalog;
            this.assets = assets;
        }

        public string[] AvailableSignIds { get { return assets.AvailableMotionSignIds(catalog); } }

        public List<LandmarkFrame> Compose(IEnumerable<string> signIds, int transitionFrames)
        {
            List<LandmarkFrame> output = new List<LandmarkFrame>();
            foreach (string signId in signIds ?? new string[0])
            {
                SignDefinition sign = catalog.FindById(signId);
                SignSequence motion = assets.LoadMotion(sign);
                if (motion == null || motion.Frames.Count == 0) continue;
                if (output.Count > 0)
                {
                    LandmarkFrame from = output[output.Count - 1];
                    LandmarkFrame to = motion.Frames[0];
                    for (int i = 1; i <= transitionFrames; i++)
                    {
                        double linear = (double)i / (transitionFrames + 1);
                        double eased = linear * linear * (3.0 - 2.0 * linear);
                        output.Add(LandmarkFrame.Interpolate(from, to, eased));
                    }
                }
                output.AddRange(motion.Frames.Select(delegate(LandmarkFrame frame) { return frame.Clone(); }));
            }
            return output;
        }

        public string[] GlossesFor(IEnumerable<string> signIds)
        {
            return (signIds ?? new string[0]).Select(delegate(string id)
            {
                SignDefinition sign = catalog.FindById(id);
                return sign == null ? id : sign.Gloss;
            }).ToArray();
        }
    }
}
