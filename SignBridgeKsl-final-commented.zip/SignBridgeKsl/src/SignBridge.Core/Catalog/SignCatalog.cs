using System;
using System.Collections.Generic;
using System.Linq;
using SignBridge.Core.Catalog.Modules;

namespace SignBridge.Core.Catalog
{
    // 수어 한 단어의 설정 카드입니다. 이 ID가 학습 라벨·번역·모션 파일을 연결합니다.
    public sealed class SignDefinition
    {
        public string Id { get; private set; }
        public string ModuleId { get; private set; }
        public string Gloss { get; private set; }
        public string RecognitionText { get; private set; }
        public string AssetRoot { get; private set; }
        public string PreferredMotionClip { get; private set; }
        public List<string> Aliases { get; private set; }

        public SignDefinition(string id, string moduleId, string gloss, string recognitionText, string assetRoot)
        {
            if (string.IsNullOrWhiteSpace(id)) throw new ArgumentNullException("id");
            if (string.IsNullOrWhiteSpace(moduleId)) throw new ArgumentNullException("moduleId");
            if (string.IsNullOrWhiteSpace(gloss)) throw new ArgumentNullException("gloss");
            Id = id.Trim();
            ModuleId = moduleId.Trim();
            Gloss = gloss.Trim();
            RecognitionText = string.IsNullOrWhiteSpace(recognitionText) ? Gloss : recognitionText.Trim();
            AssetRoot = assetRoot == null ? string.Empty : assetRoot.Trim();
            PreferredMotionClip = string.Empty;
            Aliases = new List<string> { Gloss };
        }

        public SignDefinition WithAliases(params string[] aliases)
        {
            if (aliases == null) return this;
            foreach (string alias in aliases)
                if (!string.IsNullOrWhiteSpace(alias) && !Aliases.Contains(alias.Trim(), StringComparer.OrdinalIgnoreCase))
                    Aliases.Add(alias.Trim());
            return this;
        }

        public SignDefinition WithPreferredMotion(string clipDirectoryName)
        {
            PreferredMotionClip = clipDirectoryName == null ? string.Empty : clipDirectoryName.Trim();
            return this;
        }
    }

    public sealed class TextSignRule
    {
        public string Text { get; private set; }
        public string[] SignIds { get; private set; }

        public TextSignRule(string text, params string[] signIds)
        {
            Text = text ?? string.Empty;
            SignIds = signIds ?? new string[0];
        }
    }

    public sealed class RecognitionTextRule
    {
        public string[] SignIds { get; private set; }
        public string KoreanText { get; private set; }

        public RecognitionTextRule(string koreanText, params string[] signIds)
        {
            KoreanText = koreanText ?? string.Empty;
            SignIds = signIds ?? new string[0];
        }
    }

    public interface ISignMappingModule
    {
        string ModuleId { get; }
        void Register(SignCatalogBuilder builder);
    }

    public sealed class SignCatalogBuilder
    {
        private readonly List<SignDefinition> signs = new List<SignDefinition>();
        private readonly List<TextSignRule> textRules = new List<TextSignRule>();
        private readonly List<RecognitionTextRule> recognitionRules = new List<RecognitionTextRule>();

        public void AddSign(SignDefinition sign)
        {
            if (sign == null) throw new ArgumentNullException("sign");
            if (signs.Any(delegate(SignDefinition item) { return item.Id.Equals(sign.Id, StringComparison.OrdinalIgnoreCase); }))
                throw new InvalidOperationException("Duplicate sign id: " + sign.Id);
            signs.Add(sign);
        }

        public void AddTextRule(string text, params string[] signIds)
        {
            textRules.Add(new TextSignRule(text, signIds));
        }

        public void AddRecognitionRule(string koreanText, params string[] signIds)
        {
            recognitionRules.Add(new RecognitionTextRule(koreanText, signIds));
        }

        public SignCatalog Build()
        {
            // 문장 규칙에 없는 ID를 참조하는 실수를 앱 실행 전에 발견합니다.
            HashSet<string> ids = new HashSet<string>(signs.Select(delegate(SignDefinition s) { return s.Id; }), StringComparer.OrdinalIgnoreCase);
            foreach (TextSignRule rule in textRules)
                foreach (string id in rule.SignIds)
                    if (!ids.Contains(id)) throw new InvalidOperationException("Text rule references unknown sign: " + id);
            foreach (RecognitionTextRule rule in recognitionRules)
                foreach (string id in rule.SignIds)
                    if (!ids.Contains(id)) throw new InvalidOperationException("Recognition rule references unknown sign: " + id);
            return new SignCatalog(signs, textRules, recognitionRules);
        }
    }

    public sealed class SignCatalog
    {
        private readonly List<SignDefinition> signs;
        private readonly List<TextSignRule> textRules;
        private readonly List<RecognitionTextRule> recognitionRules;
        private readonly Dictionary<string, SignDefinition> byId;

        internal SignCatalog(IEnumerable<SignDefinition> signDefinitions, IEnumerable<TextSignRule> textSignRules, IEnumerable<RecognitionTextRule> recognitionTextRules)
        {
            signs = signDefinitions.ToList();
            textRules = textSignRules.ToList();
            recognitionRules = recognitionTextRules.ToList();
            byId = signs.ToDictionary(delegate(SignDefinition s) { return s.Id; }, StringComparer.OrdinalIgnoreCase);
        }

        public IList<SignDefinition> Signs { get { return signs.AsReadOnly(); } }

        public static SignCatalog CreateDefault()
        {
            // 이 배열에 모듈을 추가하면 해당 분야의 단어가 전체 프로그램에 등록됩니다.
            SignCatalogBuilder builder = new SignCatalogBuilder();
            ISignMappingModule[] modules =
            {
                new CommonSignMappings(),
                new MedicalSignMappings(),
                new BankingSignMappings()
            };
            foreach (ISignMappingModule module in modules) module.Register(builder);
            return builder.Build();
        }

        public SignDefinition FindById(string id)
        {
            if (string.IsNullOrWhiteSpace(id)) return null;
            SignDefinition sign;
            return byId.TryGetValue(id, out sign) ? sign : null;
        }

        public SignDefinition FindByGloss(string gloss)
        {
            if (string.IsNullOrWhiteSpace(gloss)) return null;
            string normalized = Normalize(gloss);
            return signs.FirstOrDefault(delegate(SignDefinition sign)
            {
                return sign.Aliases.Any(delegate(string alias) { return Normalize(alias) == normalized; });
            });
        }

        public string[] TranslateText(string koreanText, IEnumerable<string> availableSignIds)
        {
            // 실제 좌표 모션이 있는 ID만 반환해 가짜 아바타 동작을 막습니다.
            string normalized = Normalize(koreanText);
            HashSet<string> available = new HashSet<string>(availableSignIds ?? new string[0], StringComparer.OrdinalIgnoreCase);
            TextSignRule exact = textRules.FirstOrDefault(delegate(TextSignRule rule) { return Normalize(rule.Text) == normalized; });
            if (exact != null)
                return exact.SignIds.All(delegate(string id) { return available.Contains(id); })
                    ? exact.SignIds.ToArray()
                    : new string[0];

            List<TextMatch> matches = new List<TextMatch>();
            foreach (SignDefinition sign in signs)
            {
                if (!available.Contains(sign.Id)) continue;
                foreach (string alias in sign.Aliases.OrderByDescending(delegate(string value) { return value.Length; }))
                {
                    int index = normalized.IndexOf(Normalize(alias), StringComparison.OrdinalIgnoreCase);
                    if (index < 0) continue;
                    matches.Add(new TextMatch { Index = index, Length = alias.Length, SignId = sign.Id });
                    break;
                }
            }
            return matches.OrderBy(delegate(TextMatch match) { return match.Index; })
                .ThenByDescending(delegate(TextMatch match) { return match.Length; })
                .Select(delegate(TextMatch match) { return match.SignId; })
                .Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
        }

        public string TranslateRecognition(IEnumerable<string> signIds)
        {
            // 카메라에서 순서대로 인식된 ID를 문장 규칙 또는 안전한 단어 나열로 바꿉니다.
            string[] ids = (signIds ?? new string[0]).Where(delegate(string id) { return !string.IsNullOrWhiteSpace(id); }).ToArray();
            if (ids.Length == 0) return string.Empty;
            RecognitionTextRule exact = recognitionRules.FirstOrDefault(delegate(RecognitionTextRule rule)
            {
                return rule.SignIds.SequenceEqual(ids, StringComparer.OrdinalIgnoreCase);
            });
            if (exact != null) return exact.KoreanText;

            List<string> words = new List<string>();
            foreach (string id in ids)
            {
                SignDefinition sign = FindById(id);
                words.Add(sign == null ? id : sign.RecognitionText.TrimEnd('.', '!', '?'));
            }
            return string.Join(" ", words.ToArray()) + ".";
        }

        public static string Normalize(string value)
        {
            if (value == null) return string.Empty;
            char[] remove = { '?', '.', '!', ',', '。', '？', '！' };
            string normalized = value.Trim();
            for (int i = 0; i < remove.Length; i++) normalized = normalized.Replace(remove[i].ToString(), string.Empty);
            while (normalized.Contains("  ")) normalized = normalized.Replace("  ", " ");
            return normalized.ToLowerInvariant();
        }

        private sealed class TextMatch
        {
            public int Index { get; set; }
            public int Length { get; set; }
            public string SignId { get; set; }
        }
    }
}
