using SignBridge.Core.Catalog;

namespace SignBridge.Core.Catalog.Modules
{
    // 병원·진료 상황에서 사용할 단어와 문장 규칙을 모아 둔 모듈입니다.
    public sealed class MedicalSignMappings : ISignMappingModule
    {
        public string ModuleId { get { return "medical"; } }

        public void Register(SignCatalogBuilder builder)
        {
            builder.AddSign(new SignDefinition("medical.head", ModuleId, "머리", "머리", @"medical\head"));
            builder.AddSign(new SignDefinition("medical.stomach", ModuleId, "배", "배", @"medical\stomach"));
            builder.AddSign(new SignDefinition("medical.pain", ModuleId, "아프다", "아픕니다", @"medical\pain").WithAliases("아픔", "통증", "아파", "아파요"));
            builder.AddSign(new SignDefinition("medical.treatment", ModuleId, "진료", "진료", @"medical\treatment").WithAliases("진찰", "검진"));
            builder.AddSign(new SignDefinition("medical.reservation", ModuleId, "예약", "예약", @"medical\reservation").WithAliases("접수"));
            builder.AddSign(new SignDefinition("medical.medicine", ModuleId, "약", "약", @"medical\medicine"));
            builder.AddSign(new SignDefinition("medical.prescription", ModuleId, "처방", "처방", @"medical\prescription"));
            builder.AddSign(new SignDefinition("medical.hospital", ModuleId, "병원", "병원", @"medical\hospital"));

            builder.AddTextRule("머리가 아파요", "medical.head", "medical.pain");
            builder.AddTextRule("배가 아파요", "medical.stomach", "medical.pain");
            builder.AddTextRule("병원에 가고 싶어요", "medical.hospital", "common.go", "common.want");
            builder.AddTextRule("진료 예약을 하고 싶어요", "medical.treatment", "medical.reservation", "common.want");

            builder.AddRecognitionRule("머리가 아파요.", "medical.head", "medical.pain");
            builder.AddRecognitionRule("배가 아파요.", "medical.stomach", "medical.pain");
            builder.AddRecognitionRule("병원에 가고 싶어요.", "medical.hospital", "common.go", "common.want");
            builder.AddRecognitionRule("진료 예약을 하고 싶어요.", "medical.treatment", "medical.reservation", "common.want");
        }
    }
}
