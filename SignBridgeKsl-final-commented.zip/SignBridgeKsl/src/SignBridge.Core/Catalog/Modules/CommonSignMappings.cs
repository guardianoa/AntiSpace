using SignBridge.Core.Catalog;

namespace SignBridge.Core.Catalog.Modules
{
    public sealed class CommonSignMappings : ISignMappingModule
    {
        public string ModuleId { get { return "common"; } }

        public void Register(SignCatalogBuilder builder)
        {
            // 기존 단어의 새 촬영 클립은 이 코드를 고치지 않고 AssetRoot 아래에 추가합니다.
            // 새 단어일 때만 SignDefinition과 양방향 문장 규칙을 등록합니다.
            builder.AddSign(new SignDefinition("common.singi", ModuleId, "신기하다", "신기합니다.", @"common\singi")
                .WithAliases("신기해요", "신기합니다", "신기한", "신기한데요")
                .WithPreferredMotion("NIA_SL_WORD1520_REAL01_U"));
            builder.AddSign(new SignDefinition("common.identity", ModuleId, "신분증", "신분증", @"common\identity"));
            builder.AddSign(new SignDefinition("common.here", ModuleId, "여기", "여기", @"common\here"));
            builder.AddSign(new SignDefinition("common.exist", ModuleId, "있다", "있습니다", @"common\exist").WithAliases("있어요"));
            builder.AddSign(new SignDefinition("common.want", ModuleId, "원하다", "원합니다", @"common\want").WithAliases("싶다", "바라다", "원해요"));
            builder.AddSign(new SignDefinition("common.amount", ModuleId, "얼마", "얼마예요?", @"common\amount").WithAliases("얼마예요"));
            builder.AddSign(new SignDefinition("common.help", ModuleId, "도와주다", "도와주세요.", @"common\help").WithAliases("돕다", "도움", "도와주세요"));
            builder.AddSign(new SignDefinition("common.thanks", ModuleId, "감사하다", "감사합니다.", @"common\thanks").WithAliases("감사합니다", "고맙다"));
            builder.AddSign(new SignDefinition("common.hello", ModuleId, "안녕하다", "안녕하세요.", @"common\hello").WithAliases("안녕하세요", "안녕"));
            builder.AddSign(new SignDefinition("common.yes", ModuleId, "네", "네.", @"common\yes").WithAliases("예"));
            builder.AddSign(new SignDefinition("common.no", ModuleId, "아니다", "아닙니다.", @"common\no").WithAliases("아니요"));
            builder.AddSign(new SignDefinition("common.go", ModuleId, "가다", "갑니다", @"common\go").WithAliases("가요"));

            builder.AddTextRule("신기하다", "common.singi");
            builder.AddTextRule("신기해요", "common.singi");
            builder.AddTextRule("얼마예요", "common.amount");
            builder.AddTextRule("도와주세요", "common.help");
            builder.AddTextRule("감사합니다", "common.thanks");
            builder.AddTextRule("안녕하세요", "common.hello");

            builder.AddRecognitionRule("신기합니다.", "common.singi");
            builder.AddRecognitionRule("얼마예요?", "common.amount");
            builder.AddRecognitionRule("도와주세요.", "common.help");
            builder.AddRecognitionRule("감사합니다.", "common.thanks");
            builder.AddRecognitionRule("안녕하세요.", "common.hello");
        }
    }
}
