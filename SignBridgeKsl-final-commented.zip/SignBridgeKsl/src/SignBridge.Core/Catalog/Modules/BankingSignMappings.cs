using SignBridge.Core.Catalog;

namespace SignBridge.Core.Catalog.Modules
{
    // 은행 창구에서 사용할 단어와 문장 규칙을 모아 둔 모듈입니다.
    public sealed class BankingSignMappings : ISignMappingModule
    {
        public string ModuleId { get { return "banking"; } }

        public void Register(SignCatalogBuilder builder)
        {
            builder.AddSign(new SignDefinition("banking.account", ModuleId, "계좌", "계좌", @"banking\account"));
            builder.AddSign(new SignDefinition("banking.create", ModuleId, "만들다", "만들고 싶습니다", @"banking\create").WithAliases("개설", "생성"));
            builder.AddSign(new SignDefinition("banking.money", ModuleId, "돈", "돈", @"banking\money"));
            builder.AddSign(new SignDefinition("banking.withdraw", ModuleId, "찾다", "찾고 싶습니다", @"banking\withdraw").WithAliases("출금", "인출"));
            builder.AddSign(new SignDefinition("banking.transfer", ModuleId, "이체", "이체하고 싶습니다", @"banking\transfer").WithAliases("송금", "보내다"));
            builder.AddSign(new SignDefinition("banking.bank", ModuleId, "은행", "은행", @"banking\bank"));

            builder.AddTextRule("계좌를 만들고 싶어요", "banking.account", "banking.create", "common.want");
            builder.AddTextRule("돈을 찾고 싶어요", "banking.money", "banking.withdraw", "common.want");
            builder.AddRecognitionRule("계좌를 만들고 싶어요.", "banking.account", "banking.create", "common.want");
            builder.AddRecognitionRule("돈을 찾고 싶어요.", "banking.money", "banking.withdraw", "common.want");
        }
    }
}
