using System;

namespace SignBridge.Core.Models
{
    // 한 시점의 전신·양손·얼굴 랜드마크를 담는 프레임입니다.
    [Serializable]
    public sealed class LandmarkFrame
    {
        public const int PoseCount = 8;
        public const int HandCount = 21;
        public const int BodyHandCount = PoseCount + HandCount * 2;

        public double TimeSeconds { get; set; }
        public LandmarkPoint[] BodyHands { get; set; }
        public LandmarkPoint[] Face { get; set; }

        public LandmarkFrame()
        {
            BodyHands = CreateEmpty(BodyHandCount);
            Face = new LandmarkPoint[0];
        }

        public LandmarkFrame Clone()
        {
            LandmarkFrame copy = new LandmarkFrame();
            copy.TimeSeconds = TimeSeconds;
            copy.BodyHands = ClonePoints(BodyHands);
            copy.Face = ClonePoints(Face);
            return copy;
        }

        public static LandmarkFrame Interpolate(LandmarkFrame a, LandmarkFrame b, double t)
        {
            LandmarkFrame output = new LandmarkFrame();
            output.TimeSeconds = a.TimeSeconds + (b.TimeSeconds - a.TimeSeconds) * t;
            output.BodyHands = InterpolatePoints(a.BodyHands, b.BodyHands, t, BodyHandCount);
            output.Face = InterpolatePoints(a.Face, b.Face, t, Math.Max(a.Face.Length, b.Face.Length));
            return output;
        }

        private static LandmarkPoint[] InterpolatePoints(LandmarkPoint[] a, LandmarkPoint[] b, double t, int count)
        {
            LandmarkPoint[] output = CreateEmpty(count);
            for (int i = 0; i < count; i++)
            {
                LandmarkPoint left = i < a.Length ? a[i] : null;
                LandmarkPoint right = i < b.Length ? b[i] : null;
                output[i] = LandmarkPoint.Interpolate(left, right, t);
            }
            return output;
        }

        private static LandmarkPoint[] ClonePoints(LandmarkPoint[] points)
        {
            LandmarkPoint[] output = new LandmarkPoint[points.Length];
            for (int i = 0; i < points.Length; i++)
                output[i] = points[i] == null ? new LandmarkPoint() : points[i].Clone();
            return output;
        }

        private static LandmarkPoint[] CreateEmpty(int count)
        {
            LandmarkPoint[] output = new LandmarkPoint[count];
            for (int i = 0; i < count; i++) output[i] = new LandmarkPoint();
            return output;
        }
    }
}
