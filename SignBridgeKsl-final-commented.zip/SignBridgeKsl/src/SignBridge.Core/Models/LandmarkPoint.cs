using System;

namespace SignBridge.Core.Models
{
    // 한 관절의 좌표입니다. Confidence가 낮으면 전처리 단계에서 보정 대상이 됩니다.
    [Serializable]
    public sealed class LandmarkPoint
    {
        public double X { get; set; }
        public double Y { get; set; }
        public double Z { get; set; }
        public double Confidence { get; set; }

        public bool IsValid
        {
            get { return Confidence > 0.001 && IsFinite(X) && IsFinite(Y) && IsFinite(Z); }
        }

        public LandmarkPoint()
        {
        }

        public LandmarkPoint(double x, double y, double z, double confidence)
        {
            X = x;
            Y = y;
            Z = z;
            Confidence = confidence;
        }

        public LandmarkPoint Clone()
        {
            return new LandmarkPoint(X, Y, Z, Confidence);
        }

        public static LandmarkPoint Interpolate(LandmarkPoint a, LandmarkPoint b, double t)
        {
            if (a == null || !a.IsValid) return b == null ? new LandmarkPoint() : b.Clone();
            if (b == null || !b.IsValid) return a.Clone();
            return new LandmarkPoint(
                a.X + (b.X - a.X) * t,
                a.Y + (b.Y - a.Y) * t,
                a.Z + (b.Z - a.Z) * t,
                Math.Min(a.Confidence, b.Confidence));
        }

        private static bool IsFinite(double value)
        {
            return !double.IsNaN(value) && !double.IsInfinity(value);
        }
    }
}
