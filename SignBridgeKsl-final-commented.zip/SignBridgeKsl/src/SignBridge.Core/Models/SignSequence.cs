using System;
using System.Collections.Generic;

namespace SignBridge.Core.Models
{
    // 한 번의 수어 동작(여러 프레임)을 표현합니다. Label은 Catalog의 안정 ID입니다.
    [Serializable]
    public sealed class SignSequence
    {
        public string Label { get; set; }
        public string GroupId { get; set; }
        public string SourcePath { get; set; }
        public List<LandmarkFrame> Frames { get; set; }

        public SignSequence()
        {
            Label = string.Empty;
            GroupId = string.Empty;
            SourcePath = string.Empty;
            Frames = new List<LandmarkFrame>();
        }
    }
}
