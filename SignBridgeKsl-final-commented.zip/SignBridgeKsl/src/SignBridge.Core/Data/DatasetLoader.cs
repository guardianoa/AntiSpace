using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using SignBridge.Core.Models;

namespace SignBridge.Core.Data
{
    // 클립 폴더의 JSON을 파일명 숫자 순서로 읽어 SignSequence를 만듭니다.
    public sealed class DatasetLoader
    {
        private readonly AiHubJsonParser parser;

        public DatasetLoader()
        {
            parser = new AiHubJsonParser();
        }

        public SignSequence LoadClipDirectory(string clipDirectory, string label)
        {
            if (!Directory.Exists(clipDirectory))
                throw new DirectoryNotFoundException(clipDirectory);

            string[] files = Directory.GetFiles(clipDirectory, "*.json", SearchOption.TopDirectoryOnly)
                .Where(IsKeypointFile)
                .OrderBy(NaturalFrameNumber)
                .ThenBy(delegate(string p) { return p; }, StringComparer.OrdinalIgnoreCase)
                .ToArray();
            if (files.Length == 0)
                throw new InvalidDataException("No keypoint JSON frames found in " + clipDirectory);

            SignSequence sequence = new SignSequence();
            sequence.Label = label ?? string.Empty;
            sequence.GroupId = Path.GetFileName(clipDirectory);
            sequence.SourcePath = Path.GetFullPath(clipDirectory);

            for (int i = 0; i < files.Length; i++)
            {
                LandmarkFrame frame = parser.ParseFile(files[i]);
                frame.TimeSeconds = i / 30.0;
                sequence.Frames.Add(frame);
            }
            return sequence;
        }

        public List<SignSequence> LoadDataset(string datasetRoot, out List<string> warnings)
        {
            warnings = new List<string>();
            List<SignSequence> output = new List<SignSequence>();
            if (!Directory.Exists(datasetRoot))
                throw new DirectoryNotFoundException(datasetRoot);

            string manifest = Path.Combine(datasetRoot, "manifest.csv");
            if (File.Exists(manifest))
                return LoadManifest(datasetRoot, manifest, warnings);

            string[] labelDirectories = Directory.GetDirectories(datasetRoot);
            foreach (string labelDirectory in labelDirectories.OrderBy(delegate(string p) { return p; }))
            {
                string label = Path.GetFileName(labelDirectory);
                string[] clips = Directory.GetDirectories(labelDirectory);
                if (clips.Length == 0)
                {
                    TryLoad(output, warnings, labelDirectory, label);
                    continue;
                }

                foreach (string clip in clips.OrderBy(delegate(string p) { return p; }))
                    TryLoad(output, warnings, clip, label);
            }

            if (output.Count == 0)
                warnings.Add("No sequences were loaded. Expected data/<label>/<clip>/*_keypoints.json.");
            return output;
        }

        private List<SignSequence> LoadManifest(string root, string manifest, List<string> warnings)
        {
            List<SignSequence> output = new List<SignSequence>();
            string[] lines = File.ReadAllLines(manifest);
            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i].Trim();
                if (line.Length == 0 || line.StartsWith("#")) continue;
                string[] columns = line.Split(new[] { ',' }, 2);
                if (columns.Length != 2)
                {
                    warnings.Add("manifest.csv line " + (i + 1) + " is invalid.");
                    continue;
                }
                string label = columns[0].Trim();
                string path = columns[1].Trim().Trim('"');
                if (!Path.IsPathRooted(path)) path = Path.Combine(root, path);
                TryLoad(output, warnings, path, label);
            }
            return output;
        }

        private void TryLoad(List<SignSequence> output, List<string> warnings, string path, string label)
        {
            try { output.Add(LoadClipDirectory(path, label)); }
            catch (Exception ex) { warnings.Add(path + ": " + ex.Message); }
        }

        private static bool IsKeypointFile(string path)
        {
            string name = Path.GetFileName(path);
            return name.EndsWith("_keypoints.json", StringComparison.OrdinalIgnoreCase)
                   || !name.Equals("meta.json", StringComparison.OrdinalIgnoreCase);
        }

        private static long NaturalFrameNumber(string path)
        {
            string name = Path.GetFileNameWithoutExtension(path);
            string digits = string.Empty;
            for (int i = name.Length - 1; i >= 0; i--)
            {
                if (char.IsDigit(name[i])) digits = name[i] + digits;
                else if (digits.Length > 0) break;
            }
            long value;
            return long.TryParse(digits, out value) ? value : long.MaxValue;
        }
    }
}
