using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using SignBridge.Core.Catalog;
using SignBridge.Core.Models;

namespace SignBridge.Core.Data
{
    public sealed class AssetInstallResult
    {
        public int SourceFileCount { get; set; }
        public int CopiedFileCount { get; set; }
    }

    public sealed class SignAssetStore
    {
        private readonly DatasetLoader loader;

        public string RootPath { get; private set; }

        public SignAssetStore(string rootPath)
        {
            if (string.IsNullOrWhiteSpace(rootPath)) throw new ArgumentNullException("rootPath");
            RootPath = Path.GetFullPath(rootPath);
            loader = new DatasetLoader();
        }

        public void EnsureCreated()
        {
            Directory.CreateDirectory(RootPath);
        }

        public AssetInstallResult InstallBundledAssets(string sourceRoot)
        {
            // 배포본의 예제 좌표를 사용자 폴더로 복사합니다. 기존 사용자 파일은 덮어쓰지 않습니다.
            EnsureCreated();
            AssetInstallResult result = new AssetInstallResult();
            if (string.IsNullOrWhiteSpace(sourceRoot) || !Directory.Exists(sourceRoot)) return result;
            string fullSource = Path.GetFullPath(sourceRoot).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
            foreach (string source in Directory.GetFiles(fullSource, "*.json", SearchOption.AllDirectories))
            {
                result.SourceFileCount++;
                string relative = source.Substring(fullSource.Length);
                string target = ResolveRelativePath(relative);
                string directory = Path.GetDirectoryName(target);
                if (!Directory.Exists(directory)) Directory.CreateDirectory(directory);
                if (File.Exists(target)) continue;
                File.Copy(source, target, false);
                result.CopiedFileCount++;
            }
            return result;
        }

        public List<SignSequence> LoadMappedTraining(SignCatalog catalog, out List<string> warnings)
        {
            // 폴더명을 정답으로 추측하지 않고 Catalog의 AssetRoot와 안정 ID를 사용합니다.
            if (catalog == null) throw new ArgumentNullException("catalog");
            EnsureCreated();
            warnings = new List<string>();
            List<SignSequence> sequences = new List<SignSequence>();
            foreach (SignDefinition sign in catalog.Signs)
            {
                if (string.IsNullOrWhiteSpace(sign.AssetRoot)) continue;
                string signRoot = ResolveRelativePath(sign.AssetRoot);
                if (!Directory.Exists(signRoot)) continue;
                List<string> clips = DiscoverClips(signRoot);
                foreach (string clip in clips)
                {
                    try { sequences.Add(loader.LoadClipDirectory(clip, sign.Id)); }
                    catch (Exception ex) { warnings.Add(sign.Id + " | " + clip + ": " + ex.Message); }
                }
            }
            if (sequences.Count == 0)
                warnings.Add("매핑된 좌표 클립이 없습니다. SignCatalog 모듈의 AssetRoot와 Assets 폴더를 확인하세요.");
            return sequences;
        }

        public string[] AvailableMotionSignIds(SignCatalog catalog)
        {
            return catalog.Signs.Where(delegate(SignDefinition sign) { return ResolveMotionClip(sign) != null; })
                .Select(delegate(SignDefinition sign) { return sign.Id; }).ToArray();
        }

        public SignSequence LoadMotion(SignDefinition sign)
        {
            if (sign == null) return null;
            string clip = ResolveMotionClip(sign);
            return clip == null ? null : loader.LoadClipDirectory(clip, sign.Id);
        }

        public DateTime LatestMappedWriteUtc(SignCatalog catalog)
        {
            DateTime latest = DateTime.MinValue;
            foreach (SignDefinition sign in catalog.Signs)
            {
                if (string.IsNullOrWhiteSpace(sign.AssetRoot)) continue;
                string root = ResolveRelativePath(sign.AssetRoot);
                if (!Directory.Exists(root)) continue;
                foreach (string file in Directory.GetFiles(root, "*.json", SearchOption.AllDirectories))
                    latest = File.GetLastWriteTimeUtc(file) > latest ? File.GetLastWriteTimeUtc(file) : latest;
            }
            return latest;
        }

        public string ResolveRelativePath(string relativePath)
        {
            if (string.IsNullOrWhiteSpace(relativePath)) throw new ArgumentNullException("relativePath");
            string root = Path.GetFullPath(RootPath).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
            string resolved = Path.GetFullPath(Path.Combine(root, relativePath));
            if (!resolved.StartsWith(root, StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("Asset path escapes the SignBridge data root: " + relativePath);
            return resolved;
        }

        private string ResolveMotionClip(SignDefinition sign)
        {
            // 지정된 대표 클립이 없으면 이 단어의 유효한 첫 클립을 선택합니다.
            if (string.IsNullOrWhiteSpace(sign.AssetRoot)) return null;
            string signRoot = ResolveRelativePath(sign.AssetRoot);
            if (!Directory.Exists(signRoot)) return null;
            if (!string.IsNullOrWhiteSpace(sign.PreferredMotionClip))
            {
                string preferred = Path.Combine(signRoot, sign.PreferredMotionClip);
                if (ContainsFrames(preferred)) return preferred;
            }
            return DiscoverClips(signRoot).FirstOrDefault();
        }

        private static List<string> DiscoverClips(string signRoot)
        {
            List<string> clips = Directory.GetDirectories(signRoot)
                .Where(ContainsFrames).OrderBy(delegate(string path) { return path; }, StringComparer.OrdinalIgnoreCase).ToList();
            if (clips.Count == 0 && ContainsFrames(signRoot)) clips.Add(signRoot);
            return clips;
        }

        private static bool ContainsFrames(string directory)
        {
            return Directory.Exists(directory) && Directory.GetFiles(directory, "*_keypoints.json", SearchOption.TopDirectoryOnly).Length > 0;
        }
    }
}
