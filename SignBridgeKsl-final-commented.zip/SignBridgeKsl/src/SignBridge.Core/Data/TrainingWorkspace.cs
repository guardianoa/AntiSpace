using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using SignBridge.Core.Catalog;
using SignBridge.Core.Models;
using SignBridge.Core.Recognition;

namespace SignBridge.Core.Data
{
    // 사용자 데이터 폴더와 모델 파일을 관리합니다. 성공한 학습만 current.sbm으로 교체합니다.
    public sealed class WorkspaceUpdateResult
    {
        public PrototypeModel Model { get; set; }
        public TrainingReport Training { get; set; }
        public EvaluationReport Evaluation { get; set; }
        public List<string> DataWarnings { get; set; }
        public string ReportPath { get; set; }

        public WorkspaceUpdateResult()
        {
            DataWarnings = new List<string>();
            ReportPath = string.Empty;
        }
    }

    public sealed class TrainingWorkspace
    {
        public string RootPath { get; private set; }
        public string TrainingPath { get { return Path.Combine(RootPath, "Training"); } }
        public string MotionsPath { get { return Path.Combine(RootPath, "Motions"); } }
        public string AssetsPath { get { return Path.Combine(RootPath, "Assets"); } }
        public string ModelsPath { get { return Path.Combine(RootPath, "Models"); } }
        public string ReportsPath { get { return Path.Combine(RootPath, "Reports"); } }
        public string CurrentModelPath { get { return Path.Combine(ModelsPath, "current.sbm"); } }
        public string LatestReportPath { get { return Path.Combine(ReportsPath, "latest-training-report.txt"); } }

        public static string DefaultRootPath
        {
            get
            {
                string configured = Environment.GetEnvironmentVariable("SIGNBRIDGE_DATA_ROOT");
                if (!string.IsNullOrWhiteSpace(configured)) return Path.GetFullPath(configured);
                return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "SignBridgeKslData");
            }
        }

        public TrainingWorkspace(string rootPath)
        {
            if (string.IsNullOrWhiteSpace(rootPath)) throw new ArgumentNullException("rootPath");
            RootPath = Path.GetFullPath(rootPath);
        }

        public void EnsureCreated()
        {
            Directory.CreateDirectory(TrainingPath);
            Directory.CreateDirectory(MotionsPath);
            Directory.CreateDirectory(AssetsPath);
            Directory.CreateDirectory(ModelsPath);
            Directory.CreateDirectory(ReportsPath);
            WriteIfMissing(Path.Combine(RootPath, "사용방법.txt"), RootInstructions());
            WriteIfMissing(Path.Combine(AssetsPath, "코드매핑_데이터_넣는방법.txt"), AssetInstructions());
            WriteIfMissing(Path.Combine(TrainingPath, "학습데이터_넣는방법.txt"), TrainingInstructions());
            WriteIfMissing(Path.Combine(MotionsPath, "아바타모션_넣는방법.txt"), MotionInstructions());
        }

        public WorkspaceUpdateResult UpdateModel(int frameCount, int maxExamplesPerClass)
        {
            EnsureCreated();
            DatasetLoader loader = new DatasetLoader();
            List<string> warnings;
            List<SignSequence> sequences = loader.LoadDataset(TrainingPath, out warnings);
            return BuildAndSaveModel(sequences, warnings, frameCount, maxExamplesPerClass);
        }

        public WorkspaceUpdateResult UpdateMappedModel(SignCatalog catalog, SignAssetStore assets, int frameCount, int maxExamplesPerClass)
        {
            if (catalog == null) throw new ArgumentNullException("catalog");
            if (assets == null) throw new ArgumentNullException("assets");
            EnsureCreated();
            List<string> warnings;
            List<SignSequence> sequences = assets.LoadMappedTraining(catalog, out warnings);
            return BuildAndSaveModel(sequences, warnings, frameCount, maxExamplesPerClass);
        }

        private WorkspaceUpdateResult BuildAndSaveModel(List<SignSequence> sequences, List<string> warnings, int frameCount, int maxExamplesPerClass)
        {
            if (sequences.Count == 0)
                throw new InvalidDataException("학습 가능한 매핑 클립이 없습니다. Catalog 모듈의 AssetRoot와 Assets 폴더를 확인하세요.");

            int classCount = sequences.Select(delegate(SignSequence s) { return s.Label; })
                .Distinct(StringComparer.OrdinalIgnoreCase).Count();
            if (classCount < 2)
                throw new InvalidDataException("서로 다른 수어가 최소 2개 필요합니다. 현재 라벨 수: " + classCount);

            TrainingReport training;
            PrototypeModel model = PrototypeRecognizer.Train(sequences, frameCount, maxExamplesPerClass, out training);
            List<SignSequence> evaluationSet = SelectEvaluationSet(sequences, 30);
            if (evaluationSet.Count < sequences.Count)
                warnings.Add("교차검증은 처리 시간을 제한하기 위해 전체 " + sequences.Count + "개 중 " + evaluationSet.Count + "개 클립을 라벨별 표본 평가했습니다.");
            EvaluationReport evaluation = PrototypeRecognizer.EvaluateLeaveOneOut(evaluationSet, frameCount);
            PrototypeRecognizer.Save(model, CurrentModelPath);

            WorkspaceUpdateResult result = new WorkspaceUpdateResult();
            result.Model = model;
            result.Training = training;
            result.Evaluation = evaluation;
            result.DataWarnings.AddRange(warnings);
            result.ReportPath = LatestReportPath;
            File.WriteAllText(LatestReportPath, BuildReport(result), Encoding.UTF8);
            return result;
        }

        private static List<SignSequence> SelectEvaluationSet(List<SignSequence> sequences, int maximum)
        {
            if (sequences.Count <= maximum) return sequences;
            List<IGrouping<string, SignSequence>> groups = sequences
                .GroupBy(delegate(SignSequence s) { return s.Label; }, StringComparer.OrdinalIgnoreCase).ToList();
            int perClass = Math.Max(1, maximum / Math.Max(1, groups.Count));
            List<SignSequence> selected = new List<SignSequence>();
            foreach (IGrouping<string, SignSequence> group in groups)
            {
                List<SignSequence> items = group.ToList();
                int take = Math.Min(perClass, items.Count);
                for (int i = 0; i < take; i++)
                {
                    int index = take == 1 ? 0 : (int)Math.Round(i * (items.Count - 1.0) / (take - 1.0));
                    selected.Add(items[index]);
                }
            }
            return selected.Take(maximum).ToList();
        }

        public PrototypeModel TryLoadCurrentModel()
        {
            EnsureCreated();
            return File.Exists(CurrentModelPath) ? PrototypeRecognizer.Load(CurrentModelPath) : null;
        }

        public bool HasPendingTrainingData()
        {
            EnsureCreated();
            DateTime modelTime = File.Exists(CurrentModelPath) ? File.GetLastWriteTimeUtc(CurrentModelPath) : DateTime.MinValue;
            foreach (string file in Directory.GetFiles(TrainingPath, "*.json", SearchOption.AllDirectories))
                if (File.GetLastWriteTimeUtc(file) > modelTime) return true;
            return false;
        }

        public bool HasPendingMappedTrainingData(SignCatalog catalog, SignAssetStore assets)
        {
            EnsureCreated();
            DateTime modelTime = File.Exists(CurrentModelPath) ? File.GetLastWriteTimeUtc(CurrentModelPath) : DateTime.MinValue;
            return assets.LatestMappedWriteUtc(catalog) > modelTime;
        }

        private static string BuildReport(WorkspaceUpdateResult result)
        {
            StringBuilder text = new StringBuilder();
            text.AppendLine("SignBridge 학습 보고서");
            text.AppendLine("생성 시각(UTC): " + DateTime.UtcNow.ToString("o"));
            text.AppendLine("클립 수: " + result.Training.SequenceCount);
            text.AppendLine("수어 라벨 수: " + result.Training.ClassCount);
            text.AppendLine("Leave-one-clip-out 정확도: " + result.Evaluation.Accuracy.ToString("P2"));
            text.AppendLine("평가 클립 수: " + result.Evaluation.Total);
            text.AppendLine();
            text.AppendLine("라벨별 클립 수");
            foreach (KeyValuePair<string, int> item in result.Training.SamplesPerClass.OrderBy(delegate(KeyValuePair<string, int> p) { return p.Key; }))
                text.AppendLine("- " + item.Key + ": " + item.Value);
            text.AppendLine();
            text.AppendLine("경고");
            List<string> allWarnings = new List<string>();
            allWarnings.AddRange(result.DataWarnings);
            allWarnings.AddRange(result.Training.Warnings);
            if (allWarnings.Count == 0) text.AppendLine("- 없음");
            else foreach (string warning in allWarnings) text.AppendLine("- " + warning);
            text.AppendLine();
            text.AppendLine("주의: 이 정확도는 독립 화자 최종 시험을 대신하지 않습니다.");
            return text.ToString();
        }

        private static void WriteIfMissing(string path, string content)
        {
            if (!File.Exists(path)) File.WriteAllText(path, content, Encoding.UTF8);
        }

        private string RootInstructions()
        {
            return "SignBridge 데이터 저장소\r\n\r\n" +
                   "현재 사용 위치(인식 학습 + 아바타 공용): " + AssetsPath + "\r\n" +
                   "현재 모델: " + CurrentModelPath + "\r\n" +
                   "학습 보고서: " + LatestReportPath + "\r\n\r\n" +
                   "단어 ID, 별칭, 문장, 자산 상대경로는 C# Catalog/Modules에서 관리합니다.\r\n" +
                   "기존 단어의 새 클립은 매핑된 Assets 경로 아래에 추가한 뒤 '모델 업데이트'를 누르세요.\r\n" +
                   "Training과 Motions는 이전 버전 호환 폴더이며 새 운영 데이터는 Assets에 넣으세요.\r\n";
        }

        private static string AssetInstructions()
        {
            return "C# 코드 매핑 수어 자산 구조\r\n\r\n" +
                   "Assets\\<모듈>\\<수어키>\\<촬영자-세션-클립>\\*_keypoints.json\r\n\r\n" +
                   "예시: Assets\\common\\singi\\signer02-session01\\000000_keypoints.json\r\n" +
                   "정답 단어는 폴더명이 아니라 src\\SignBridge.Core\\Catalog\\Modules의 SignDefinition으로 결정됩니다.\r\n" +
                   "기존 단어에 새 클립을 추가할 때는 코드를 바꾸지 않습니다.\r\n" +
                   "새 단어는 먼저 C# 모듈에 영구 ID와 AssetRoot를 등록하세요.\r\n" +
                   "각 클립은 여러 시간순 프레임 JSON으로 구성되어야 합니다.\r\n";
        }

        private static string TrainingInstructions()
        {
            return "이 폴더는 이전 버전 호환용입니다. 새 운영 데이터는 Assets와 C# Catalog 매핑을 사용하세요.\r\n\r\n" +
                   "이전 학습 좌표 폴더 구조\r\n\r\n" +
                   "Training\\<수어명>\\<촬영자-세션-클립>\\*_keypoints.json\r\n\r\n" +
                   "예시:\r\n" +
                   "Training\\안녕하세요\\signer01-session01-clip001\\000000_keypoints.json\r\n" +
                   "Training\\안녕하세요\\signer01-session01-clip001\\000001_keypoints.json\r\n" +
                   "Training\\감사합니다\\signer02-session01-clip001\\000000_keypoints.json\r\n\r\n" +
                   "지원 형식: AI Hub OpenPose people 객체의 2D 또는 3D JSON.\r\n" +
                   "수어 이름 폴더와 클립 폴더를 반드시 분리하세요.\r\n" +
                   "같은 사람의 프레임을 여러 클립으로 잘라 테스트셋에 섞지 마세요.\r\n";
        }

        private static string MotionInstructions()
        {
            return "이 폴더는 이전 버전 호환용입니다. 새 아바타 모션은 Assets와 C# Catalog 매핑을 사용하세요.\r\n\r\n" +
                   "이전 텍스트→아바타 모션 구조\r\n\r\n" +
                   "Motions\\<글로스>\\<클립>\\*_keypoints.json\r\n\r\n" +
                   "예시: Motions\\도와주다\\default\\000000_keypoints.json\r\n" +
                   "각 모션은 농인 한국수어 사용자의 감수를 받은 좌표만 등록하세요.\r\n";
        }
    }
}
