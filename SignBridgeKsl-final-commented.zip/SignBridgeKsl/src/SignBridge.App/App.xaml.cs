using System.Windows;

namespace SignBridge.App
{
    // WPF 애플리케이션 진입점입니다. 화면 구성은 MainWindow.xaml에 있습니다.
    public partial class App : Application
    {
    }
}
