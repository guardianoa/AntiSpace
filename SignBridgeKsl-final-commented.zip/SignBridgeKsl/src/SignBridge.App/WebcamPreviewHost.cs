using System;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;

namespace SignBridge.App
{
    public sealed class WebcamPreviewHost : HwndHost
    {
        // Windows 기본 카메라 영상을 WPF 화면 안에 표시합니다.
        // 영상 표시와 손·얼굴 좌표 추출은 별도 UDP 모듈의 책임입니다.
        private const int WsChild = 0x40000000;
        private const int WsVisible = 0x10000000;
        private const int WsClipChildren = 0x02000000;
        private const int WsClipSiblings = 0x04000000;
        private const uint WmCapStart = 0x0400;
        private const uint WmCapDriverConnect = WmCapStart + 10;
        private const uint WmCapDriverDisconnect = WmCapStart + 11;
        private const uint WmCapSetPreview = WmCapStart + 50;
        private const uint WmCapSetPreviewRate = WmCapStart + 52;
        private const uint WmCapSetScale = WmCapStart + 53;

        private IntPtr captureWindow;

        public bool IsCameraRunning { get; private set; }

        public bool StartCamera(int cameraIndex)
        {
            if (captureWindow == IntPtr.Zero) return false;
            if (IsCameraRunning) return true;
            // 일부 노트북은 내장 카메라가 1번으로 등록되므로 요청 인덱스부터 몇 개를 순서대로 시험합니다.
            for (int index = Math.Max(0, cameraIndex); index < Math.Max(cameraIndex + 1, 5); index++)
            {
                IntPtr connected = SendMessage(captureWindow, WmCapDriverConnect, new IntPtr(index), IntPtr.Zero);
                if (connected == IntPtr.Zero) continue;
                ApplyPreviewSettings();
                IsCameraRunning = true;
                return true;
            }
            return false;
        }

        public void StopCamera()
        {
            if (captureWindow == IntPtr.Zero || !IsCameraRunning) return;
            SendMessage(captureWindow, WmCapSetPreview, IntPtr.Zero, IntPtr.Zero);
            SendMessage(captureWindow, WmCapDriverDisconnect, IntPtr.Zero, IntPtr.Zero);
            IsCameraRunning = false;
        }

        protected override HandleRef BuildWindowCore(HandleRef hwndParent)
        {
            captureWindow = CapCreateCaptureWindow("SignBridge Camera", WsChild | WsVisible | WsClipChildren | WsClipSiblings, 0, 0, 640, 480, hwndParent.Handle, 0);
            if (captureWindow == IntPtr.Zero) throw new InvalidOperationException("Windows 웹캠 미리보기 창을 만들 수 없습니다.");
            return new HandleRef(this, captureWindow);
        }

        protected override void DestroyWindowCore(HandleRef hwnd)
        {
            StopCamera();
            if (hwnd.Handle != IntPtr.Zero) DestroyWindow(hwnd.Handle);
            captureWindow = IntPtr.Zero;
        }

        protected override void OnWindowPositionChanged(Rect rcBoundingBox)
        {
            base.OnWindowPositionChanged(rcBoundingBox);
            if (captureWindow != IntPtr.Zero)
            {
                MoveWindow(captureWindow, 0, 0, Math.Max(1, (int)rcBoundingBox.Width), Math.Max(1, (int)rcBoundingBox.Height), true);
                if (IsCameraRunning) ApplyPreviewSettings();
            }
        }

        private void ApplyPreviewSettings()
        {
            MoveWindow(captureWindow, 0, 0, Math.Max(1, (int)ActualWidth), Math.Max(1, (int)ActualHeight), true);
            SendMessage(captureWindow, WmCapSetScale, new IntPtr(1), IntPtr.Zero);
            SendMessage(captureWindow, WmCapSetPreviewRate, new IntPtr(33), IntPtr.Zero);
            SendMessage(captureWindow, WmCapSetPreview, new IntPtr(1), IntPtr.Zero);
        }

        [DllImport("avicap32.dll", CharSet = CharSet.Unicode, EntryPoint = "capCreateCaptureWindowW")]
        private static extern IntPtr CapCreateCaptureWindow(string windowName, int style, int x, int y, int width, int height, IntPtr parent, int id);

        [DllImport("user32.dll")]
        private static extern IntPtr SendMessage(IntPtr window, uint message, IntPtr wParam, IntPtr lParam);

        [DllImport("user32.dll")]
        private static extern bool MoveWindow(IntPtr window, int x, int y, int width, int height, bool repaint);

        [DllImport("user32.dll")]
        private static extern bool DestroyWindow(IntPtr window);
    }
}
