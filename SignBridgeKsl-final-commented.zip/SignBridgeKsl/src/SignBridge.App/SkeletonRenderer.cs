using System;
using System.Collections.Generic;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using SignBridge.Core.Models;

namespace SignBridge.App
{
    // 2D 좌표 확인용 보조 렌더러입니다. 주 화면은 3D AvatarRenderer를 사용합니다.
    internal sealed class SkeletonRenderer
    {
        private static readonly int[,] PoseEdges = { { 0, 1 }, { 1, 2 }, { 2, 3 }, { 3, 4 }, { 1, 5 }, { 5, 6 }, { 6, 7 }, { 2, 5 } };
        private static readonly int[,] HandEdges =
        {
            {0,1},{1,2},{2,3},{3,4}, {0,5},{5,6},{6,7},{7,8},
            {0,9},{9,10},{10,11},{11,12}, {0,13},{13,14},{14,15},{15,16},
            {0,17},{17,18},{18,19},{19,20}
        };

        private readonly Canvas canvas;

        public SkeletonRenderer(Canvas canvas)
        {
            this.canvas = canvas;
        }

        public void Render(LandmarkFrame frame)
        {
            canvas.Children.Clear();
            if (frame == null) return;
            Bounds bounds = FindBounds(frame);
            DrawFace(frame.Face, bounds);
            DrawEdges(frame.BodyHands, PoseEdges, 0, bounds, Brushes.DeepSkyBlue, 5.0);
            DrawEdges(frame.BodyHands, HandEdges, LandmarkFrame.PoseCount, bounds, Brushes.MediumSpringGreen, 3.0);
            DrawEdges(frame.BodyHands, HandEdges, LandmarkFrame.PoseCount + LandmarkFrame.HandCount, bounds, Brushes.Orange, 3.0);
            DrawConnection(frame.BodyHands, 7, LandmarkFrame.PoseCount, bounds, Brushes.MediumSpringGreen, 4.0);
            DrawConnection(frame.BodyHands, 4, LandmarkFrame.PoseCount + LandmarkFrame.HandCount, bounds, Brushes.Orange, 4.0);
            DrawJoints(frame.BodyHands, bounds);
        }

        private void DrawFace(LandmarkPoint[] points, Bounds bounds)
        {
            if (points == null) return;
            for (int i = 0; i < points.Length; i++)
            {
                if (points[i] == null || !points[i].IsValid) continue;
                System.Windows.Point p = Map(points[i], bounds);
                Ellipse dot = new Ellipse { Width = 2.5, Height = 2.5, Fill = Brushes.MediumPurple, Opacity = 0.8 };
                Canvas.SetLeft(dot, p.X - 1.25); Canvas.SetTop(dot, p.Y - 1.25); canvas.Children.Add(dot);
            }
        }

        private void DrawJoints(LandmarkPoint[] points, Bounds bounds)
        {
            for (int i = 0; i < points.Length; i++)
            {
                if (points[i] == null || !points[i].IsValid) continue;
                System.Windows.Point p = Map(points[i], bounds);
                int handIndex = i < LandmarkFrame.PoseCount ? -1 : (i - LandmarkFrame.PoseCount) % LandmarkFrame.HandCount;
                bool fingerTip = handIndex == 4 || handIndex == 8 || handIndex == 12 || handIndex == 16 || handIndex == 20;
                double size = i < LandmarkFrame.PoseCount ? 9.0 : (fingerTip ? 8.0 : 6.0);
                Brush color = i < LandmarkFrame.PoseCount ? Brushes.White :
                    (i < LandmarkFrame.PoseCount + LandmarkFrame.HandCount ? Brushes.MediumSpringGreen : Brushes.Orange);
                Ellipse dot = new Ellipse { Width = size, Height = size, Fill = color };
                Canvas.SetLeft(dot, p.X - size * 0.5); Canvas.SetTop(dot, p.Y - size * 0.5); canvas.Children.Add(dot);
            }
        }

        private void DrawEdges(LandmarkPoint[] points, int[,] edges, int offset, Bounds bounds, Brush color, double thickness)
        {
            for (int i = 0; i < edges.GetLength(0); i++)
            {
                int from = offset + edges[i, 0], to = offset + edges[i, 1];
                if (from >= points.Length || to >= points.Length || !points[from].IsValid || !points[to].IsValid) continue;
                System.Windows.Point a = Map(points[from], bounds), b = Map(points[to], bounds);
                canvas.Children.Add(new Line { X1 = a.X, Y1 = a.Y, X2 = b.X, Y2 = b.Y, Stroke = color, StrokeThickness = thickness, StrokeStartLineCap = PenLineCap.Round, StrokeEndLineCap = PenLineCap.Round });
            }
        }

        private void DrawConnection(LandmarkPoint[] points, int from, int to, Bounds bounds, Brush color, double thickness)
        {
            if (from >= points.Length || to >= points.Length || !points[from].IsValid || !points[to].IsValid) return;
            System.Windows.Point a = Map(points[from], bounds), b = Map(points[to], bounds);
            canvas.Children.Add(new Line { X1 = a.X, Y1 = a.Y, X2 = b.X, Y2 = b.Y, Stroke = color, StrokeThickness = thickness, StrokeStartLineCap = PenLineCap.Round, StrokeEndLineCap = PenLineCap.Round });
        }

        private System.Windows.Point Map(LandmarkPoint point, Bounds bounds)
        {
            double width = Math.Max(100.0, canvas.ActualWidth), height = Math.Max(100.0, canvas.ActualHeight);
            double padding = 28.0;
            double scaleX = (width - padding * 2) / Math.Max(1e-8, bounds.MaxX - bounds.MinX);
            double scaleY = (height - padding * 2) / Math.Max(1e-8, bounds.MaxY - bounds.MinY);
            double scale = Math.Min(scaleX, scaleY);
            double usedWidth = (bounds.MaxX - bounds.MinX) * scale;
            double usedHeight = (bounds.MaxY - bounds.MinY) * scale;
            return new System.Windows.Point(
                (width - usedWidth) * 0.5 + (point.X - bounds.MinX) * scale,
                (height - usedHeight) * 0.5 + (point.Y - bounds.MinY) * scale);
        }

        private static Bounds FindBounds(LandmarkFrame frame)
        {
            List<LandmarkPoint> valid = new List<LandmarkPoint>();
            AddValid(valid, frame.BodyHands); AddValid(valid, frame.Face);
            if (valid.Count == 0) return new Bounds { MinX = -1, MaxX = 1, MinY = -1, MaxY = 1 };
            double minX = double.MaxValue, minY = double.MaxValue, maxX = double.MinValue, maxY = double.MinValue;
            foreach (LandmarkPoint p in valid) { minX = Math.Min(minX, p.X); minY = Math.Min(minY, p.Y); maxX = Math.Max(maxX, p.X); maxY = Math.Max(maxY, p.Y); }
            double xPad = Math.Max((maxX - minX) * 0.12, 0.01), yPad = Math.Max((maxY - minY) * 0.12, 0.01);
            return new Bounds { MinX = minX - xPad, MaxX = maxX + xPad, MinY = minY - yPad, MaxY = maxY + yPad };
        }

        private static void AddValid(List<LandmarkPoint> target, LandmarkPoint[] source)
        {
            if (source == null) return;
            foreach (LandmarkPoint point in source) if (point != null && point.IsValid) target.Add(point);
        }

        private sealed class Bounds { public double MinX, MaxX, MinY, MaxY; }
    }
}
