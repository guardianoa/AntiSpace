using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Threading;
using Microsoft.Win32;
using SignBridge.Core.Catalog;
using SignBridge.Core.Data;
using SignBridge.Core.Models;
using SignBridge.Core.Processing;
using SignBridge.Core.Recognition;
using SignBridge.Core.Streaming;
using SignBridge.Core.Translation;

namespace SignBridge.App
{
    public partial class MainWindow : Window
    {
        private readonly DatasetLoader datasetLoader;
        private readonly DispatcherTimer playbackTimer;
        private readonly object liveSync;
        private readonly List<string> recognizedSignIds;
        private List<LandmarkFrame> inputClipFrames;
        private List<LandmarkFrame> avatarPlaybackFrames;
        private int playbackIndex;
        private bool livePredictionRunning;
        private PrototypeRecognizer recognizer;
        private UdpLandmarkSource udpSource;
        private SpeechInputService speech;
        private AvatarRenderer avatar;
        private SignCatalog catalog;
        private SignAssetStore assetStore;
        private MappedMotionLibrary motionLibrary;
        private TrainingWorkspace workspace;
        private MotionSegmenter liveSegmenter;
        private DateTime lastRecognitionUtc;

        public MainWindow()
        {
            InitializeComponent();
            datasetLoader = new DatasetLoader();
            inputClipFrames = new List<LandmarkFrame>();
            avatarPlaybackFrames = new List<LandmarkFrame>();
            recognizedSignIds = new List<string>();
            liveSync = new object();
            playbackTimer = new DispatcherTimer(DispatcherPriority.Render);
            playbackTimer.Interval = TimeSpan.FromMilliseconds(1000.0 / 30.0);
            playbackTimer.Tick += PlaybackTimer_Tick;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // 시작 순서: 작업 폴더 생성 → Catalog 준비 → 번들 자산 설치 → 모델·아바타 준비
            avatar = new AvatarRenderer(AvatarViewport);
            workspace = new TrainingWorkspace(TrainingWorkspace.DefaultRootPath);
            workspace.EnsureCreated();
            catalog = SignCatalog.CreateDefault();
            assetStore = new SignAssetStore(workspace.AssetsPath);
            string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
            AssetInstallResult install = assetStore.InstallBundledAssets(Path.Combine(baseDirectory, "sign-assets"));
            liveSegmenter = new MotionSegmenter();
            motionLibrary = new MappedMotionLibrary(catalog, assetStore);
            speech = new SpeechInputService();
            speech.TextRecognized += Speech_TextRecognized;
            TryLoadWorkspaceModel();
            Status((install.CopiedFileCount > 0 ? "코드 매핑 수어 자산 " + install.CopiedFileCount + "개 파일을 등록했습니다. · " : string.Empty) +
                   (workspace.HasPendingMappedTrainingData(catalog, assetStore) ? "새 매핑 데이터가 있습니다. · " : string.Empty) +
                   "수어 자산: " + workspace.AssetsPath);
        }

        private void OpenClip_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "AI Hub keypoint JSON|*_keypoints.json|JSON|*.json";
            dialog.Title = "클립의 아무 키포인트 프레임 하나를 선택하세요";
            if (dialog.ShowDialog(this) != true) return;
            try
            {
                string directory = Path.GetDirectoryName(dialog.FileName);
                SignSequence sequence = datasetLoader.LoadClipDirectory(directory, Path.GetFileName(directory));
                inputClipFrames = sequence.Frames.Select(delegate(LandmarkFrame frame) { return frame.Clone(); }).ToList();
                InputModeText.Text = "파일 · " + Path.GetFileName(directory) + " · " + sequence.Frames.Count + "프레임";
                Status("좌표 클립을 불러왔습니다. '현재 클립 인식'을 누르세요.");
            }
            catch (Exception ex) { ShowError(ex); }
        }

        private void OpenModel_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "SignBridge model|*.sbm|JSON|*.json";
            if (dialog.ShowDialog(this) != true) return;
            try
            {
                recognizer = new PrototypeRecognizer(PrototypeRecognizer.Load(dialog.FileName));
                ModelStatusText.Text = recognizer.Model.Classes.Count + "개 수어 · " + Path.GetFileName(dialog.FileName);
                Status("인식 모델을 불러왔습니다.");
            }
            catch (Exception ex) { ShowError(ex); }
        }

        private void TrainModel_Click(object sender, RoutedEventArgs e)
        {
            Status("추가된 전체 좌표를 검사하고 모델을 업데이트하는 중입니다.");
            ThreadPool.QueueUserWorkItem(delegate
            {
                try
                {
                    WorkspaceUpdateResult result = workspace.UpdateMappedModel(catalog, assetStore, 60, 12);
                    Dispatcher.BeginInvoke(new Action(delegate
                    {
                        recognizer = new PrototypeRecognizer(result.Model);
                        ModelStatusText.Text = result.Model.Classes.Count + "개 수어 · 자동 모델";
                        string warnings = string.Join(" ", result.DataWarnings.Concat(result.Training.Warnings).ToArray());
                        Status("모델 업데이트 완료: " + result.Training.SequenceCount + "개 클립, " +
                               result.Training.ClassCount + "개 수어, 교차검증 " + result.Evaluation.Accuracy.ToString("P1") +
                               (warnings.Length == 0 ? string.Empty : " · 경고: " + warnings));
                    }));
                }
                catch (Exception ex) { Dispatcher.BeginInvoke(new Action(delegate { ShowError(ex); })); }
            });
        }

        private void OpenTrainingFolder_Click(object sender, RoutedEventArgs e)
        {
            workspace.EnsureCreated();
            OpenFolder(workspace.AssetsPath);
            Status("수어 데이터 위치는 Catalog/Modules의 AssetRoot 매핑으로 관리됩니다.");
        }

        private void OpenMotionFolder_Click(object sender, RoutedEventArgs e)
        {
            workspace.EnsureCreated();
            OpenFolder(workspace.AssetsPath);
            Status("인식 학습과 아바타 모션은 같은 매핑 자산을 사용합니다.");
        }

        private void Recognize_Click(object sender, RoutedEventArgs e)
        {
            if (recognizer == null) { Status("먼저 모델을 열거나 데이터를 학습하세요."); return; }
            if (inputClipFrames.Count == 0) { Status("먼저 좌표 클립을 여세요."); return; }
            try { ShowRecognition(recognizer.Predict(inputClipFrames)); }
            catch (Exception ex) { ShowError(ex); }
        }

        private void ToggleCamera_Click(object sender, RoutedEventArgs e)
        {
            // 카메라 버튼은 영상 표시만 켭니다. 좌표 인식은 별도 버튼으로 시작합니다.
            try
            {
                if (CameraPreview.IsCameraRunning)
                {
                    CameraPreview.StopCamera();
                    CameraButton.Content = "웹캠 시작";
                    InputModeText.Text = "웹캠 정지";
                    return;
                }
                if (!CameraPreview.StartCamera(0))
                    throw new InvalidOperationException("웹캠을 열 수 없습니다. 다른 프로그램이 카메라를 사용 중인지 확인하세요.");
                CameraButton.Content = "웹캠 중지";
                InputModeText.Text = "웹캠 표시 중 · 좌표 인식은 별도 시작";
            }
            catch (Exception ex) { ShowError(ex); }
        }

        private void ToggleUdp_Click(object sender, RoutedEventArgs e)
        {
            // 외부 랜드마크 추출기의 JSON 프레임을 받아 실시간 인식을 시작합니다.
            try
            {
                if (udpSource != null && udpSource.IsRunning)
                {
                    udpSource.Stop(); UdpButton.Content = "좌표 인식 시작"; InputModeText.Text = "좌표 인식 중지";
                    return;
                }
                udpSource = new UdpLandmarkSource();
                udpSource.FrameReceived += Udp_FrameReceived;
                udpSource.Error += Udp_Error;
                udpSource.Start(50505);
                liveSegmenter.Reset();
                UdpButton.Content = "좌표 인식 중지"; InputModeText.Text = "웹캠 + 실시간 좌표 · 127.0.0.1:50505";
                Status("AI Hub 형식 JSON 프레임을 UDP 50505 포트로 기다리는 중입니다.");
            }
            catch (Exception ex) { ShowError(ex); }
        }

        private void Udp_FrameReceived(object sender, FrameReceivedEventArgs e)
        {
            List<LandmarkFrame> completed;
            lock (liveSync)
            {
                completed = liveSegmenter.AddFrame(e.Frame);
            }
            Dispatcher.BeginInvoke(new Action(delegate
            {
                InputModeText.Text = liveSegmenter.IsRecording ? "웹캠 · 수어 동작 기록 중" : "웹캠 · 수어 동작 대기";
            }));
            if (completed != null) QueueLivePrediction(completed);
        }

        private void QueueLivePrediction(List<LandmarkFrame> snapshot)
        {
            lock (liveSync)
            {
                if (recognizer == null || livePredictionRunning) return;
                livePredictionRunning = true;
            }
            ThreadPool.QueueUserWorkItem(delegate
            {
                try
                {
                    RecognitionResult result = recognizer.Predict(snapshot);
                    Dispatcher.BeginInvoke(new Action(delegate { ShowRecognition(result); }));
                }
                catch (Exception ex) { Dispatcher.BeginInvoke(new Action(delegate { Status("실시간 인식 오류: " + ex.Message); })); }
                finally { lock (liveSync) livePredictionRunning = false; }
            });
        }

        private void Udp_Error(object sender, SourceErrorEventArgs e)
        {
            Dispatcher.BeginInvoke(new Action(delegate { Status("UDP 오류: " + e.Error.Message); }));
        }

        private void PlayText_Click(object sender, RoutedEventArgs e)
        {
            // 한국어 → Catalog 수어 ID → 검증된 좌표 모션 → 3D 아바타 순서로 처리합니다.
            try
            {
                string[] available = motionLibrary.AvailableSignIds;
                if (available.Length == 0)
                {
                    Status("코드 매핑과 일치하는 수어 모션 자산이 없습니다.");
                    return;
                }
                string[] signIds = catalog.TranslateText(KoreanInput.Text, available);
                if (signIds.Length == 0) { Status("등록된 매핑 모션으로 표현할 수 없는 문장입니다."); return; }
                List<LandmarkFrame> frames = motionLibrary.Compose(signIds, 8);
                StartPlayback(frames);
                Status("글로스: " + string.Join(" → ", motionLibrary.GlossesFor(signIds)));
            }
            catch (Exception ex) { ShowError(ex); }
        }

        private void ToggleSpeech_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (speech.IsListening) { speech.Stop(); SpeechButton.Content = "음성 입력 시작"; Status("음성 입력을 중지했습니다."); }
                else { speech.Start(); SpeechButton.Content = "음성 입력 중지"; Status("한국어 음성을 듣고 있습니다."); }
            }
            catch (Exception ex) { ShowError(ex); }
        }

        private void Speech_TextRecognized(object sender, TextRecognizedEventArgs e)
        {
            Dispatcher.BeginInvoke(new Action(delegate { KoreanInput.Text = e.Text; Status("음성 인식: " + e.Text); }));
        }

        private void StopPlayback_Click(object sender, RoutedEventArgs e)
        {
            playbackTimer.Stop();
            Status("3D 모션 재생을 중지했습니다.");
        }

        private void StartPlayback(IEnumerable<LandmarkFrame> frames)
        {
            avatarPlaybackFrames = frames.Select(delegate(LandmarkFrame f) { return f.Clone(); }).ToList();
            playbackIndex = 0;
            if (avatarPlaybackFrames.Count > 0) { avatar.Render(avatarPlaybackFrames[0]); playbackTimer.Start(); }
        }

        private void PlaybackTimer_Tick(object sender, EventArgs e)
        {
            if (playbackIndex >= avatarPlaybackFrames.Count) { playbackTimer.Stop(); return; }
            avatar.Render(avatarPlaybackFrames[playbackIndex++]);
        }

        private void ShowRecognition(RecognitionResult result)
        {
            if (!result.Rejected)
            {
                DateTime now = DateTime.UtcNow;
                bool duplicateBurst = recognizedSignIds.Count > 0 &&
                    recognizedSignIds[recognizedSignIds.Count - 1].Equals(result.Label, StringComparison.OrdinalIgnoreCase) &&
                    (now - lastRecognitionUtc).TotalMilliseconds < 1500;
                if (!duplicateBurst) recognizedSignIds.Add(result.Label);
                if (recognizedSignIds.Count > 12) recognizedSignIds.RemoveAt(0);
                lastRecognitionUtc = now;
            }
            string translated = result.Rejected ? "알 수 없음" : catalog.TranslateRecognition(recognizedSignIds);
            RecognitionText.Text = translated;
            ConfidenceText.Text = "신뢰도 " + result.Confidence.ToString("P1") + " · 거리 " + result.Distance.ToString("F5") +
                (result.Rejected ? " · " + result.Reason : string.Empty);
            if (!result.Rejected) Status("수어 인식: " + translated + " · ID " + result.Label);
        }

        private void ClearRecognition_Click(object sender, RoutedEventArgs e)
        {
            recognizedSignIds.Clear();
            lastRecognitionUtc = DateTime.MinValue;
            RecognitionText.Text = "—";
            ConfidenceText.Text = "신뢰도 —";
            Status("수어 번역 문장을 지웠습니다.");
        }

        private void Status(string message) { StatusText.Text = message; }
        private void ShowError(Exception ex) { Status("오류: " + ex.Message); }

        private void TryLoadWorkspaceModel()
        {
            try
            {
                PrototypeModel model = workspace.TryLoadCurrentModel();
                if (model == null) { ModelStatusText.Text = "자동 모델 없음"; return; }
                recognizer = new PrototypeRecognizer(model);
                ModelStatusText.Text = model.Classes.Count + "개 수어 · 자동 로드";
            }
            catch (Exception ex)
            {
                ModelStatusText.Text = "모델 로드 오류";
                Status("기존 모델을 불러오지 못했습니다: " + ex.Message);
            }
        }

        private static void OpenFolder(string path)
        {
            Process.Start(new ProcessStartInfo { FileName = path, UseShellExecute = true });
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            playbackTimer.Stop();
            CameraPreview.StopCamera();
            if (udpSource != null) udpSource.Dispose();
            if (speech != null) speech.Dispose();
        }
    }
}
