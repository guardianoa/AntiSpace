# 데이터 수집·학습·평가 가이드

## 목표 범위부터 정하기

전체 한국수어를 한 번에 목표로 하지 말고 첫 설치 장소의 대화 30~100개를 선정하십시오. 의료 진단, 계약, 금융 의사결정처럼 오역 피해가 큰 영역은 초기 자동화 대상에서 제외하고 전문 수어통역사 또는 필담 연결을 기본 폴백으로 두는 편이 안전합니다.

단어 목록과 표현은 농인 한국수어 사용자와 공동으로 정해야 합니다. 한국어 단어 목록을 그대로 수어 목록으로 가정하면 실제 언어 사용과 어긋날 수 있습니다.

## 코드 매핑과 폴더 구조

새 운영 데이터의 기본 위치는 다음과 같습니다.

```text
C:\Users\<Windows 사용자명>\Documents\SignBridgeKslData\Assets
```

앱의 `수어 자산 폴더` 버튼이 이 위치를 엽니다. 정답 라벨은 폴더의 한글 이름에서 추론하지 않고 `src\SignBridge.Core\Catalog\Modules\*.cs`의 `SignDefinition`으로 결정합니다.

```text
Assets
└─ <SignDefinition.AssetRoot>
   ├─ <signer-id>-<session-id>-<clip-id>
   │  ├─ 000000_keypoints.json
   │  └─ 000001_keypoints.json
   └─ <다른 클립>
```

예를 들어 `common.singi`의 `AssetRoot`가 `common\singi`이면 다음 폴더들이 모두 같은 클래스의 서로 다른 클립입니다.

```text
Assets\common\singi\signer01-session01-clip001\*.json
Assets\common\singi\signer02-session01-clip001\*.json
```

새 단어 등록과 문장 규칙은 `MAPPING_GUIDE.md`를 따르십시오.

## 반복 업데이트 절차

1. `수어 자산 폴더`를 누릅니다.
2. 기존 단어이면 매핑된 `AssetRoot` 아래에 새 클립 폴더를 추가합니다.
3. 새 단어이면 C# 모듈에 영구 ID, 별칭, `AssetRoot`와 문장 규칙을 먼저 등록합니다.
4. 기존 클립을 덮어쓰지 말고 새 클립 폴더에 시간순 JSON을 넣습니다.
5. `모델 업데이트`를 누릅니다.
6. 클립 수·수어 ID 수·평가 결과·경고를 확인합니다.
7. 상세 결과는 `Documents\SignBridgeKslData\Reports\latest-training-report.txt`에서 확인합니다.

학습이 성공한 경우에만 `Models\current.sbm`이 교체되며 이전 정상 모델은 `current.sbm.bak`으로 보존됩니다.

## 수집 원칙

- 같은 사람이 같은 자리에서 반복한 샘플만 늘리지 않습니다.
- 사람, 날짜, 카메라, 배경, 조명, 옷, 속도, 좌우잡이, 지역 변이를 기록합니다.
- 손만 자르지 말고 상반신, 양손, 얼굴, 시선이 동시에 보이게 촬영합니다.
- 한 클립에는 수어 동작 한 번만 넣고 시작·종료 중립 자세를 일관되게 합니다.
- 손·얼굴의 누락률과 confidence 분포를 촬영 직후 검사합니다.
- 원본 영상의 목적, 보유 기간, 학습 재사용, 제3자 제공, 철회 절차를 동의서에 분리합니다.
- `signer-id`는 직접 식별자와 분리한 무작위 코드로 관리합니다.
- 빈 동작, 자연스러운 손짓, 카메라 이탈을 UNKNOWN/BLANK 평가 데이터로 따로 수집합니다.

PoC 시작점으로 클래스당 여러 사람·여러 세션의 수십 클립을 권장하지만 정확도를 보장하는 숫자는 아닙니다. 파일 수보다 독립 화자 다양성이 더 중요합니다.

## 데이터 분할

같은 원본 영상의 프레임이나 같은 사람의 인접 반복을 무작위로 나누면 데이터 누수가 생깁니다.

- 학습: 화자 집합 A
- 검증: 임계값과 모델 선택용 화자 집합 B
- 최종 테스트: 개발 중 전혀 보지 않은 화자 집합 C

같은 사람, 같은 세션, 같은 원본 영상에서 파생된 클립은 반드시 한 분할에만 둡니다.

## 평가 지표

- 고립 단어: 클래스별 precision/recall/F1, macro F1, 혼동행렬
- 연속수어: 글로스 오류율과 문장 의미 정확도
- 미등록 동작: false accept rate와 false reject rate
- 사용자 결과: 농인 평가자의 이해도, 자연스러움, 과업 완료율
- 운영: P50/P95 지연, 프레임 드롭, 카메라 실패율, 통역사 폴백 비율

전체 평균 정확도 하나만 보고 출시하지 마십시오. 손가락 모양이 비슷한 단어와 얼굴 표정이 문법 기능을 갖는 의문·부정·강조 표현을 별도 평가해야 합니다.

## CLI

```powershell
SignBridge.Cli.exe workspace
SignBridge.Cli.exe update
SignBridge.Cli.exe inspect --clip C:\ksl\one-clip
SignBridge.Cli.exe predict --model C:\ksl\model.sbm --clip C:\ksl\one-clip
SignBridge.Cli.exe evaluate --data C:\ksl\evaluation-dataset
```

운영 모델에는 코드 매핑을 사용하는 `update`를 권장합니다. 현재 leave-one-clip-out 평가는 개발 회귀 확인용이며 독립 화자 최종 시험을 대신하지 않습니다.
