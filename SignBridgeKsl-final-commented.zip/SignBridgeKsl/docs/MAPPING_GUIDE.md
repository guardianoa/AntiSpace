# C# 코드 기반 수어 매핑·데이터 추가 가이드

## 1. 이 버전의 핵심 원칙

단어 폴더의 한글 이름을 프로그램이 임의로 정답으로 해석하지 않습니다. 수어 단어는 C# 모듈에 한 번 등록하고, 이후 모든 좌표 클립은 그 등록 정보의 `AssetRoot`에 연결합니다.

예를 들어 `신기하다`는 다음 하나의 안정적인 ID로 관리됩니다.

```text
ID: common.singi
표시 글로스: 신기하다
인식 결과 문장: 신기합니다.
자산 경로: common\singi
대표 아바타 클립: NIA_SL_WORD1520_REAL01_U
```

`common.singi`는 모델 파일, 인식 결과, 문장 규칙, 아바타 모션을 연결하는 내부 계약입니다. 출시 후에는 이 ID를 바꾸지 마십시오. 한글 표기, 별칭, 대표 모션은 바꿔도 ID는 유지하는 것이 이전 모델과의 호환성을 지키는 방법입니다.

## 2. 매핑 소스 위치

```text
src\SignBridge.Core\Catalog\SignCatalog.cs
src\SignBridge.Core\Catalog\Modules\CommonSignMappings.cs
src\SignBridge.Core\Catalog\Modules\MedicalSignMappings.cs
src\SignBridge.Core\Catalog\Modules\BankingSignMappings.cs
```

- `SignCatalog.cs`: 매핑 자료형, 중복 ID 검사, 한국어→수어 ID, 수어 ID→한국어 변환
- `CommonSignMappings.cs`: 인사·감사·도움 등 공통 단어
- `MedicalSignMappings.cs`: 병원·진료 상황 단어와 문장
- `BankingSignMappings.cs`: 은행 상황 단어와 문장

분야가 늘어나면 기존 파일 하나를 크게 만들지 말고 `TransportSignMappings`, `GovernmentOfficeSignMappings`처럼 모듈 파일을 추가하십시오. 새 모듈은 `SignCatalog.CreateDefault()`의 `modules` 배열에 등록합니다.

## 3. 좌표데이터를 넣는 실제 폴더

프로그램에서 `수어 자산 폴더` 버튼을 누르면 정확한 폴더가 열립니다. 기본값은 다음과 같습니다.

```text
C:\Users\<사용자>\Documents\SignBridgeKslData\Assets\
```

`신기하다`의 현재 구조는 다음과 같습니다.

```text
Assets
└─ common
   └─ singi
      └─ NIA_SL_WORD1520_REAL01_U
         ├─ NIA_SL_WORD1520_REAL01_U_000000000000_keypoints.json
         ├─ NIA_SL_WORD1520_REAL01_U_000000000001_keypoints.json
         └─ ... 총 124프레임
```

각 `clip` 폴더 하나가 수어를 한 번 수행한 시간 순서입니다. JSON 하나를 동작 하나로 취급하지 마십시오.

## 4. 기존 단어의 새 촬영 데이터를 추가하는 방법

`신기하다`의 촬영자·각도·세션을 추가하는 경우 C# 매핑 코드는 수정할 필요가 없습니다. `common\singi` 아래에 겹치지 않는 새 클립 폴더만 추가합니다.

```text
Assets\common\singi\signer02-session01-front\*.json
Assets\common\singi\signer02-session02-left15\*.json
Assets\common\singi\signer03-session01-front\*.json
```

그 후 앱의 `모델 업데이트`를 누릅니다. 프로그램은 `common.singi`에 연결된 모든 클립을 다시 읽습니다. 아바타는 `PreferredMotionClip`로 지정된 대표 클립을 사용하며, 지정된 클립이 없으면 유효한 첫 번째 클립을 사용합니다.

## 5. 새 수어 단어를 추가하는 방법

예를 들어 병원 모듈에 `열`을 추가하려면 `MedicalSignMappings.Register`에 다음과 같이 등록합니다.

```csharp
builder.AddSign(
    new SignDefinition(
        "medical.fever",          // 영구적으로 유지할 내부 ID
        ModuleId,                 // medical
        "열",                     // 화면에 표시할 글로스
        "열이 납니다.",           // 이 수어를 인식했을 때 표시할 기본 한국어
        @"medical\fever")         // Assets 아래 상대경로
    .WithAliases("발열", "열나요", "열이 나요")
    .WithPreferredMotion("approved-v001"));

builder.AddTextRule("열이 나요", "medical.fever");
builder.AddRecognitionRule("열이 나요.", "medical.fever");
```

그리고 데이터를 다음 위치에 추가합니다.

```text
Assets\medical\fever\approved-v001\*.json
Assets\medical\fever\signer02-session01\*.json
```

마지막으로 자동 테스트에 ID, 별칭, 문장 규칙, 모션 로딩 검사를 추가하고 전체 빌드를 실행합니다.

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\build.ps1
```

## 6. 문장 매핑 규칙

두 방향을 분리해 관리합니다.

- `AddTextRule`: 일반인의 한국어 문장을 수어 ID 순서로 변환
- `AddRecognitionRule`: 연속 인식된 수어 ID 순서를 자연스러운 한국어 문장으로 변환

```csharp
builder.AddTextRule(
    "머리가 아파요",
    "medical.head",
    "medical.pain");

builder.AddRecognitionRule(
    "머리가 아파요.",
    "medical.head",
    "medical.pain");
```

정확한 문장 규칙이 없을 때는 등록된 별칭을 입력문에서 찾되, 실제 좌표 모션이 존재하는 ID만 재생합니다. 따라서 텍스트에 단어가 있어도 검증된 모션 데이터가 없으면 아바타가 임의 동작을 만들어 내지 않습니다.

## 7. 데이터 품질 규칙

- 최소 2개 이상의 서로 다른 수어 ID가 있어야 분류 모델의 의미가 생깁니다.
- 단어마다 여러 농인 화자, 여러 날짜, 옷·배경·거리·조명 조건을 포함하십시오.
- 한 클립에 한 동작만 넣고 시작·종료의 중립 자세를 일관되게 유지하십시오.
- 왼손·오른손을 임의 반전하지 말고 촬영·좌표 변환 규칙을 고정하십시오.
- 손 21점씩, 상체 8점, 얼굴 70점이 누락되는 비율을 수집 단계에서 기록하십시오.
- 학습과 평가는 같은 화자의 인접 프레임을 나누는 방식이 아니라 화자·세션 단위로 분리하십시오.
- `approved-*` 대표 모션은 농인 한국수어 사용자의 검수를 거친 버전만 지정하십시오.

## 8. 버전·운영 권장사항

- 매핑 변경은 Git으로 검토하고 코드 리뷰를 통과시킵니다.
- `SignDefinition.Id`는 삭제보다 비활성화 정책을 두고, 과거 모델과 로그를 해석할 수 있게 유지합니다.
- 데이터셋에는 촬영 동의, 화자 익명 ID, 장비, FPS, 해상도, 검수자, 라이선스를 별도 메타데이터로 기록합니다.
- 의료·금융처럼 오역 위험이 큰 문장은 낮은 신뢰도에서 `알 수 없음`으로 안전하게 거절하고 문자·필담·수어통역 연결 수단을 함께 제공합니다.
- 운영 데이터와 원본 영상은 최소 수집 원칙, 암호화, 보존기간, 삭제 요청 절차를 적용합니다.

## 9. 현재 포함된 자산

현재 배포본에 실제로 포함된 모션은 사용자 제공 `신기하다` 한 클립, 124프레임입니다. 공통·의료·은행의 다른 단어는 코드 매핑 틀만 존재하며 좌표데이터가 아직 없으므로 재생·학습 대상으로 나타나지 않습니다. 새 단어의 데이터를 넣기 전에 반드시 위 방식으로 모듈에 등록해야 합니다.
