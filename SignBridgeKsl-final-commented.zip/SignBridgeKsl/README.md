# SignBridge 한국수어 번역 프로그램

원본 Python 프로젝트 44개 파일과 제공 좌표데이터를 다시 검토해 C#/.NET Framework 4.8 WPF로 재구성한 확장형 MVP입니다. 원본처럼 단어와 문장을 소스코드에서 매핑하되, 유지보수를 위해 `common.singi` 같은 영구 ID와 분야별 C# 모듈을 사용합니다.

## 화면과 동작

- 왼쪽: 실제 웹캠 미리보기, 좌표 인식 상태, 인식된 수어의 한국어 문장과 신뢰도
- 오른쪽: 한국어 텍스트·음성 입력, 등록된 좌표 모션을 재생하는 3D 아바타
- 좌표: 상체 8점, 왼손 21점, 오른손 21점, 얼굴 70점과 2D/3D 값 처리
- 인식: 결측 보정, 평활화, 길이 통일, 위치·크기 정규화, DTW 프로토타입, 미등록 동작 거절
- 운영: 코드 매핑 자산 자동 발견, 모델 안전 교체와 백업, CLI, 8개 자동 테스트

현재 포함된 실제 모션은 사용자 제공 `신기하다` 124프레임입니다. 이 데이터는 다음 C# 매핑에 연결되어 인식 학습과 3D 아바타가 함께 사용합니다.

```text
common.singi → 신기하다 → Assets\common\singi\NIA_SL_WORD1520_REAL01_U
```

## 실행

압축을 푼 다음 아래 파일을 실행합니다.

```text
dist\SignBridge.App\SignBridge.App.exe
```

필요 환경은 Windows x64와 .NET Framework 4.8입니다. `SignBridgeKsl.sln`은 일반 텍스트 파일이 아니라 Visual Studio 솔루션이므로 VS Code의 “일반 텍스트 디버깅”으로 실행하지 마십시오. Visual Studio 2022에서 솔루션을 열거나 위 EXE를 직접 실행하십시오.

소스를 빌드하려면 Visual Studio 2022의 `.NET 데스크톱 개발` 워크로드와 .NET Framework 4.8 Developer Pack을 설치하고 다음을 실행합니다.

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\build.ps1
powershell -ExecutionPolicy Bypass -File .\scripts\run.ps1
```

## 단어와 데이터를 계속 추가하는 방법

앱의 `수어 자산 폴더` 버튼이 정확한 사용자 데이터 위치를 엽니다. 기본 구조는 다음과 같습니다.

```text
C:\Users\<사용자>\Documents\SignBridgeKslData\
├─ Assets
│  ├─ common\singi\클립명\*.json
│  ├─ medical\head\클립명\*.json
│  └─ banking\account\클립명\*.json
├─ Models
└─ Reports
```

- 기존 단어에 촬영 클립 추가: 해당 매핑의 `AssetRoot` 아래에 새 클립 폴더만 추가
- 새 단어 추가: `src\SignBridge.Core\Catalog\Modules`의 분야별 C# 파일에 `SignDefinition`을 한 번 등록한 뒤 그 `AssetRoot`에 클립 추가
- 새 문장 추가: 같은 모듈의 `AddTextRule`과 `AddRecognitionRule`에 수어 ID 순서를 등록
- 데이터 추가 후: 앱의 `모델 업데이트` 실행

정확한 예제와 운영 규칙은 [MAPPING_GUIDE.md](docs/MAPPING_GUIDE.md)에 있습니다.

## 카메라 인식 연결

웹캠 버튼은 왼쪽 화면에 실제 영상을 표시합니다. 손·얼굴·몸 좌표는 교체 가능한 랜드마크 추출기가 AI Hub `people` 객체 형식의 JSON 프레임을 `127.0.0.1:50505`로 보내는 구조입니다. 앱의 `좌표 인식 시작` 버튼이 이 입력을 받아 동작 구간을 자르고 모델로 인식합니다.

현재 배포본에는 카메라 영상을 좌표로 바꾸는 MediaPipe/ONNX 모델 자체가 포함되지 않았습니다. 원본 Python에도 배포 가능한 학습 체크포인트가 없었기 때문에 존재하지 않는 모델을 이식된 것처럼 만들지 않았습니다. 연결 규격은 [CAMERA_INTEGRATION.md](docs/CAMERA_INTEGRATION.md)에 설명되어 있습니다.

## 현재 수준을 정확히 이해하기

제공된 `신기하다`는 한 단어·한 클립뿐이라 다른 수어와 구분하는 유효한 분류 모델을 아직 만들 수 없습니다. 최소 두 수어 ID, 그리고 단어마다 여러 농인 화자·세션의 독립 클립이 필요합니다. 현재 결과물은 좌표 파싱, 손가락·얼굴 특징, 코드 매핑, 학습, 인식, 3D 재생이 연결된 기술 MVP이지 상용 수준의 연속 한국수어 번역 정확도를 보장하는 완성 제품은 아닙니다.

## 문서

- [README2 상세 설명서](README2.md)
- [단어 매핑·데이터 추가 가이드](docs/MAPPING_GUIDE.md)
- [원본 Python 44개 파일 전수 검토](docs/PYTHON_FULL_AUDIT.md)
- [데이터 수집·학습·평가](docs/DATASET_GUIDE.md)
- [카메라/UDP 연동](docs/CAMERA_INTEGRATION.md)
- [C# 구조](docs/ARCHITECTURE.md)
- [제품·안전·사업화 검토](docs/PRODUCT_AND_SAFETY.md)

## 검증 결과

- Release 전체 솔루션 빌드 성공
- 자동 테스트 8/8 통과
- 원본 `신기하다` 124프레임 파싱 성공
- 프레임당 상체·양손 관절 50/50, 얼굴 70점, 3D 값 확인
- 코드 매핑→자산 발견→학습 라벨→텍스트 모션의 회귀 테스트 통과

빌드 컴퓨터에는 .NET Framework 4.8 Developer Pack의 참조 어셈블리가 없어 GAC 대체 경고가 표시됐지만 빌드와 테스트는 성공했습니다. 개발 PC에는 Developer Pack을 설치하는 것을 권장합니다.
