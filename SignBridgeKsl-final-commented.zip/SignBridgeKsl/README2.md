# SignBridge 한국수어 번역 프로그램 상세 설명서

이 문서는 프로그래밍을 처음 접하는 분을 위한 사용 설명서입니다. 먼저 1~3장만 따라 실행하고, 좌표데이터를 추가할 때는 5장을 읽으십시오. 소스코드를 수정할 때는 8장을 읽으면 됩니다.

## 1. 프로그램이 하는 일

화면을 왼쪽과 오른쪽으로 나누어 두 사람이 서로 다른 방식으로 의사소통합니다.

```text
왼쪽: 농인 사용자의 웹캠 + 수어 인식 결과 한국어
오른쪽: 일반 사용자의 한국어 입력 + 3D 수어 아바타
```

한국수어는 손바닥만의 언어가 아닙니다. 손가락 마디, 손 방향, 위치, 이동, 양손 관계와 눈썹·눈·입·시선·머리·몸 방향이 함께 의미를 만듭니다. 프로그램은 상체 8점, 왼손 21점, 오른손 21점, 얼굴 70점을 처리합니다.

## 2. 처음 실행하기

1. ZIP을 압축 해제합니다.
2. `dist\SignBridge.App\SignBridge.App.exe`를 두 번 클릭합니다.
3. 왼쪽에서 `웹캠 시작`을 누릅니다.
4. 오른쪽 입력창의 `신기해요`를 확인하고 `3D 수어 재생`을 누릅니다.
5. 왼쪽의 `수어 자산 폴더` 버튼을 누르면 데이터를 넣을 폴더가 열립니다.

Windows x64와 .NET Framework 4.8이 필요합니다. `SignBridgeKsl.sln`은 실행 파일이 아니므로 VS Code에서 일반 텍스트 디버깅으로 실행하지 말고, Visual Studio 2022에서 열거나 EXE를 직접 실행하십시오.

## 3. 왼쪽과 오른쪽의 차이

### 왼쪽: 수어에서 한국어

웹캠 화면을 표시하는 기능과 손·얼굴 좌표를 계산하는 기능은 분리되어 있습니다.

```text
웹캠 표시 → 랜드마크 추출기 → JSON 좌표를 UDP 127.0.0.1:50505로 전송
          → 좌표 인식 시작 → 동작 분할 → 모델 인식 → 한국어 표시
```

현재 ZIP에는 웹캠 표시, UDP 좌표 수신, 인식 기능이 들어 있습니다. 영상에서 좌표를 계산하는 MediaPipe/ONNX 모델은 원본 폴더에 제공되지 않았기 때문에 별도 연결이 필요합니다. 자세한 규격은 `docs\CAMERA_INTEGRATION.md`를 읽으십시오.

### 오른쪽: 한국어에서 수어 아바타

입력한 한국어가 C# 코드에 등록된 규칙과 일치하고 실제 좌표 모션이 있으면 아바타가 재생합니다. 등록되지 않은 동작을 임의로 만들어 내지 않습니다. 현재 실제 모션은 `신기하다` 한 단어입니다.

## 4. 프레임·클립·단어 이해하기

- 프레임: 특정 시각의 관절 좌표 JSON 파일 하나
- 클립: 수어를 한 번 한 시간 순서 프레임 폴더
- 단어: 여러 클립을 묶은 하나의 수어 ID

```text
신기하다
└─ 한 번의 클립
   ├─ 000000_keypoints.json
   ├─ 000001_keypoints.json
   └─ ...
```

JSON 하나는 단어 하나가 아닙니다. 제공된 `신기하다` 데이터는 124개 프레임입니다.

## 5. 좌표데이터 추가하기

### 5.1 데이터 폴더

앱에서 `수어 자산 폴더`를 누릅니다. 기본 위치는 다음과 같습니다.

```text
C:\Users\<사용자명>\Documents\SignBridgeKslData\Assets
```

### 5.2 기존 단어의 새 클립 추가

`신기하다`의 촬영 데이터를 더할 때는 소스코드를 수정하지 않습니다. 아래처럼 새 클립 폴더만 추가합니다.

```text
Assets\common\singi\signer02-session01-front\000000_keypoints.json
Assets\common\singi\signer02-session01-front\000001_keypoints.json
Assets\common\singi\signer03-session02-left15\000000_keypoints.json
```

기존 파일을 덮어쓰지 말고 화자·세션별 새 폴더를 만드십시오. 추가 후 앱의 `모델 업데이트`를 누릅니다.

### 5.3 새 단어 등록

폴더만 만드는 것으로는 새 단어가 등록되지 않습니다.

1. `src\SignBridge.Core\Catalog\Modules`에서 분야별 C# 파일을 엽니다.
2. `SignDefinition`에 영구 ID, 표시 이름, 자산 경로를 등록합니다.
3. 별칭과 한국어→수어 규칙을 등록합니다.
4. 수어→한국어 인식 규칙을 등록합니다.
5. 등록한 경로에 JSON 클립을 넣습니다.
6. 빌드·테스트 후 모델을 업데이트합니다.

```csharp
builder.AddSign(
    new SignDefinition(
        "medical.fever",       // 출시 후 바꾸지 않을 내부 ID
        ModuleId,               // 현재 모듈 이름
        "열",                  // 화면 표시 이름
        "열이 납니다.",         // 인식 결과 문장
        @"medical\fever")      // Assets 아래 상대경로
    .WithAliases("발열", "열나요")
    .WithPreferredMotion("approved-v001"));

builder.AddTextRule("열이 나요", "medical.fever");
builder.AddRecognitionRule("열이 나요.", "medical.fever");
```

좌표는 `Assets\medical\fever\approved-v001\*.json`에 넣습니다. `common.singi`와 같은 ID는 모델과 로그에 사용되므로 나중에 이름을 바꾸거나 재사용하지 마십시오.

### 5.4 문장 규칙

```csharp
builder.AddTextRule("머리가 아파요", "medical.head", "medical.pain");
builder.AddRecognitionRule("머리가 아파요.", "medical.head", "medical.pain");
```

두 방향을 따로 등록하는 이유는 한국어와 한국수어의 어순·공간 표현·표정 문법이 항상 같지 않기 때문입니다. 문장 규칙은 농인 한국수어 사용자와 함께 검수하십시오.

## 6. 버튼 설명

| 화면 | 버튼 | 기능 |
|---|---|---|
| 왼쪽 | 웹캠 시작/중지 | 실제 카메라 영상 표시/정지 |
| 왼쪽 | 좌표 클립 열기 | JSON 프레임 클립 선택 |
| 왼쪽 | 모델 열기 | `.sbm` 모델 선택 |
| 왼쪽 | 수어 자산 폴더 | `Assets` 폴더 열기 |
| 왼쪽 | 모델 업데이트 | 매핑된 좌표를 다시 학습 |
| 왼쪽 | 좌표 인식 시작 | UDP 50505 실시간 인식 시작 |
| 왼쪽 | 번역 지우기 | 누적 번역 문장 삭제 |
| 오른쪽 | 3D 수어 재생 | 입력 문장을 등록 모션으로 재생 |
| 오른쪽 | 음성 입력 시작 | Windows 한국어 음성을 입력창에 기록 |
| 오른쪽 | 재생 정지 | 아바타 재생 중지 |

## 7. 아바타와 좌표

아바타는 관절 선만 그리지 않습니다. 머리·목·가슴·복부·골반을 입체 형태로 표시하고 상박·하박을 피부색 형태로 표시합니다. 왼손과 오른손의 21개 관절 및 손가락 마디, 얼굴 좌표도 함께 표시합니다. 카메라 시야와 아바타 크기는 손이 화면 밖으로 잘리지 않도록 조정되어 있습니다.

현재는 좌표·축·손가락·표정 파이프라인을 확인하는 진단용 아바타입니다. 상용 아바타에는 손 리그, 관절 제한, 얼굴 블렌드셰이프, 시선, 몸 방향, 단어 연결 동작과 농인 감수가 추가로 필요합니다.

## 8. 소스코드 읽는 순서

처음에는 다음 순서로 읽으십시오.

1. `src\SignBridge.App\MainWindow.xaml` — 화면 배치와 버튼
2. `src\SignBridge.App\MainWindow.xaml.cs` — 버튼을 눌렀을 때의 흐름
3. `src\SignBridge.Core\Catalog\SignCatalog.cs` — 수어 ID와 번역 규칙
4. `src\SignBridge.Core\Catalog\Modules\CommonSignMappings.cs` — 실제 단어 등록 예제
5. `src\SignBridge.Core\Data\SignAssetStore.cs` — Assets와 JSON 연결
6. `src\SignBridge.Core\Processing\KeypointProcessor.cs` — 좌표 보정·정규화
7. `src\SignBridge.Core\Recognition\PrototypeRecognizer.cs` — 현재 인식기
8. `src\SignBridge.App\AvatarRenderer.cs` — 3D 아바타
9. `src\SignBridge.App\WebcamPreviewHost.cs` — 웹캠 표시

주요 파일에는 한국어 주석이 있습니다. 주석은 “무엇을 하는가”뿐 아니라 “왜 이렇게 분리했는가”도 설명합니다.

## 9. 학습 과정

1. Catalog에 등록된 자산 경로만 탐색합니다.
2. 각 JSON 클립을 시간순으로 읽습니다.
3. 누락값 보정, 평활화, 60프레임 리샘플링, 어깨 기준 정규화를 수행합니다.
4. 손가락·얼굴을 포함해 특징을 만들고 현재 DTW 모델을 학습합니다.
5. 성공한 경우에만 `Models\current.sbm`을 교체합니다.
6. 이전 모델은 `current.sbm.bak`, 결과는 `Reports\latest-training-report.txt`에 남깁니다.

서로 다른 수어 ID가 두 개 이상 필요합니다. `신기하다` 클립만 많이 넣어도 다른 동작을 구별할 수 없습니다.

## 10. 문제 해결

### VS Code에서 일반 텍스트 디버깅 팝업

`.sln`은 실행 파일이 아닙니다. `dist\SignBridge.App\SignBridge.App.exe`를 직접 실행하거나 Visual Studio에서 솔루션을 여십시오.

### 웹캠을 눌렀는데 얼굴이 안 보임

Windows 카메라 권한을 허용하고 Teams·Zoom·브라우저를 닫은 뒤 다시 실행합니다. 프로그램은 카메라 0~4번을 순서대로 시도합니다. 영상은 보이지만 번역이 안 되면 랜드마크 추출기가 UDP 50505로 JSON을 보내는지 확인하십시오.

### 모델 업데이트 오류

“서로 다른 수어가 최소 2개 필요”는 정상 안전장치입니다. 두 번째 수어를 C# 모듈에 등록하고 좌표 클립을 추가하십시오.

### 텍스트를 입력해도 아바타가 안 움직임

현재 실제 자산은 `신기하다`뿐입니다. `신기해요`로 먼저 시험하고, 새 단어는 모듈 등록과 Assets 좌표 추가를 모두 했는지 확인하십시오.

## 11. 빌드·테스트

Visual Studio 2022와 .NET Framework 4.8 Developer Pack을 설치하고 실행합니다.

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\build.ps1
```

현재 자동 테스트 8개가 있으며 JSON 파싱, 정규화, 리샘플링, 학습·인식, 동작 분할, 코드 매핑, 모션 합성을 확인합니다. 테스트 통과가 모든 한국수어의 정확도를 보장하는 것은 아니므로, 출시 전에는 학습에 참여하지 않은 농인 화자 테스트셋을 별도로 운영해야 합니다.

## 12. 유지보수와 제품 운영

- 출시한 수어 ID는 바꾸거나 다른 단어에 재사용하지 않습니다.
- 기존 단어의 새 촬영은 코드 수정 없이 AssetRoot 아래 새 클립으로 추가합니다.
- 새 단어는 코드 매핑·좌표 자산·자동 테스트·농인 검수를 한 번에 진행합니다.
- 원본 영상과 얼굴 좌표는 동의, 암호화, 접근권한, 보존기간, 삭제 절차를 적용합니다.
- 의료·금융처럼 오역 위험이 큰 안내에는 전문 통역·필담 폴백을 제공합니다.
- 낮은 신뢰도는 임의 번역 대신 `알 수 없음`으로 표시합니다.

현재 결과물은 좌표 파싱, 손가락·얼굴 특징, 코드 매핑, 학습, 인식, 웹캠 표시, 3D 모션이 연결된 확장형 기술 MVP입니다. 단어와 화자 데이터를 계속 추가하고 카메라 랜드마크 추출기와 상용 아바타를 보강하면 제품을 단계적으로 발전시킬 수 있습니다.
