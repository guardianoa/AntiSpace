$ErrorActionPreference = 'Stop'

$projectRoot = Split-Path -Parent $PSScriptRoot
$outputsRoot = Split-Path -Parent $projectRoot
$archivePath = Join-Path $outputsRoot 'SignBridgeKsl.zip'
$temporaryRoot = Join-Path ([System.IO.Path]::GetTempPath()) ('signbridge-package-' + [Guid]::NewGuid().ToString('N'))
$packageRoot = Join-Path $temporaryRoot 'SignBridgeKsl'
$temporaryArchive = Join-Path $temporaryRoot 'SignBridgeKsl.zip'

try {
    & (Join-Path $PSScriptRoot 'build.ps1')
    if ($LASTEXITCODE -ne 0) { throw "빌드 또는 테스트 실패: $LASTEXITCODE" }

    New-Item -ItemType Directory -Path $packageRoot -Force | Out-Null
    foreach ($name in @('README.md', 'README2.md', 'SignBridgeKsl.sln')) {
        Copy-Item -LiteralPath (Join-Path $projectRoot $name) -Destination $packageRoot
    }
    foreach ($name in @('docs', 'scripts', 'sample-data')) {
        $source = Join-Path $projectRoot $name
        if (Test-Path -LiteralPath $source) {
            Copy-Item -LiteralPath $source -Destination $packageRoot -Recurse
        }
    }

    foreach ($name in @('src', 'tests')) {
        $source = Join-Path $projectRoot $name
        $target = Join-Path $packageRoot $name
        New-Item -ItemType Directory -Path $target -Force | Out-Null
        & robocopy $source $target /E /XD bin obj .vs /NFL /NDL /NJH /NJS /NP | Out-Null
        if ($LASTEXITCODE -gt 7) { throw "소스 복사 실패($name): $LASTEXITCODE" }
    }

    $appRelease = Join-Path $projectRoot 'src\SignBridge.App\bin\Release'
    $cliRelease = Join-Path $projectRoot 'src\SignBridge.Cli\bin\Release'
    $appDist = Join-Path $packageRoot 'dist\SignBridge.App'
    $cliDist = Join-Path $packageRoot 'dist\SignBridge.Cli'
    New-Item -ItemType Directory -Path $appDist, $cliDist -Force | Out-Null
    Get-ChildItem -LiteralPath $appRelease -File | Copy-Item -Destination $appDist
    Get-ChildItem -LiteralPath $cliRelease -File | Copy-Item -Destination $cliDist
    Copy-Item -LiteralPath (Join-Path $appRelease 'sign-assets') -Destination $appDist -Recurse

    Compress-Archive -LiteralPath $packageRoot -DestinationPath $temporaryArchive -CompressionLevel Optimal
    if (Test-Path -LiteralPath $archivePath) {
        $backup = Join-Path $outputsRoot ('SignBridgeKsl-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.previous.zip')
        Move-Item -LiteralPath $archivePath -Destination $backup
    }
    Move-Item -LiteralPath $temporaryArchive -Destination $archivePath
    Write-Host "압축 완료: $archivePath"
}
finally {
    $resolvedTemp = [System.IO.Path]::GetFullPath($temporaryRoot)
    $systemTemp = [System.IO.Path]::GetFullPath([System.IO.Path]::GetTempPath())
    if ($resolvedTemp.StartsWith($systemTemp, [StringComparison]::OrdinalIgnoreCase) -and (Test-Path -LiteralPath $resolvedTemp)) {
        Remove-Item -LiteralPath $resolvedTemp -Recurse -Force
    }
}
